﻿namespace Pateints_Manager
{
    partial class Mainform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.tb_nextOfKinT = new System.Windows.Forms.TextBox();
            this.tb_NextOfKinAD = new System.Windows.Forms.TextBox();
            this.tb_NextOfKin = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cb_Ward = new System.Windows.Forms.ComboBox();
            this.cb_Folder = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tb_PhoneNo = new System.Windows.Forms.TextBox();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnFinger = new System.Windows.Forms.Button();
            this.btnPhoto = new System.Windows.Forms.Button();
            this.PbFinger = new System.Windows.Forms.PictureBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.PbPhoto = new System.Windows.Forms.PictureBox();
            this.cb_LocalGvt = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cb_GenoType = new System.Windows.Forms.ComboBox();
            this.cb_BloodGp = new System.Windows.Forms.ComboBox();
            this.tb_Surname = new System.Windows.Forms.TextBox();
            this.tb_Othernames = new System.Windows.Forms.TextBox();
            this.tb_Firstname = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbFinger)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(208, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(687, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hospital Patients  Management Platform.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(273, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(455, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ebonyi State University Teaching Hospital";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(410, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "PMB 1013, Abakiliki";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Firstname:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCancel);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.btnRead);
            this.groupBox1.Controls.Add(this.btnWrite);
            this.groupBox1.Controls.Add(this.tb_nextOfKinT);
            this.groupBox1.Controls.Add(this.tb_NextOfKinAD);
            this.groupBox1.Controls.Add(this.tb_NextOfKin);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.cb_Ward);
            this.groupBox1.Controls.Add(this.cb_Folder);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.tb_PhoneNo);
            this.groupBox1.Controls.Add(this.tb_Address);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.btnFinger);
            this.groupBox1.Controls.Add(this.btnPhoto);
            this.groupBox1.Controls.Add(this.PbFinger);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.PbPhoto);
            this.groupBox1.Controls.Add(this.cb_LocalGvt);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.cb_GenoType);
            this.groupBox1.Controls.Add(this.cb_BloodGp);
            this.groupBox1.Controls.Add(this.tb_Surname);
            this.groupBox1.Controls.Add(this.tb_Othernames);
            this.groupBox1.Controls.Add(this.tb_Firstname);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 109);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1047, 549);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " Personal Details";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(807, 495);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(116, 35);
            this.btnCancel.TabIndex = 40;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(628, 495);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(116, 35);
            this.btnSave.TabIndex = 39;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(402, 495);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(97, 35);
            this.btnRead.TabIndex = 38;
            this.btnRead.Text = "READ";
            this.btnRead.UseVisualStyleBackColor = true;
            // 
            // btnWrite
            // 
            this.btnWrite.AutoSize = true;
            this.btnWrite.Location = new System.Drawing.Point(171, 495);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(107, 35);
            this.btnWrite.TabIndex = 37;
            this.btnWrite.Text = "WRITE";
            this.btnWrite.UseVisualStyleBackColor = true;
            // 
            // tb_nextOfKinT
            // 
            this.tb_nextOfKinT.Location = new System.Drawing.Point(171, 408);
            this.tb_nextOfKinT.Name = "tb_nextOfKinT";
            this.tb_nextOfKinT.Size = new System.Drawing.Size(230, 29);
            this.tb_nextOfKinT.TabIndex = 36;
            // 
            // tb_NextOfKinAD
            // 
            this.tb_NextOfKinAD.Location = new System.Drawing.Point(157, 364);
            this.tb_NextOfKinAD.Name = "tb_NextOfKinAD";
            this.tb_NextOfKinAD.Size = new System.Drawing.Size(230, 29);
            this.tb_NextOfKinAD.TabIndex = 35;
            // 
            // tb_NextOfKin
            // 
            this.tb_NextOfKin.Location = new System.Drawing.Point(157, 316);
            this.tb_NextOfKin.Name = "tb_NextOfKin";
            this.tb_NextOfKin.Size = new System.Drawing.Size(238, 29);
            this.tb_NextOfKin.TabIndex = 34;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(0, 408);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(151, 24);
            this.label18.TabIndex = 33;
            this.label18.Text = "Telephone No:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(14, 367);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(99, 24);
            this.label17.TabIndex = 32;
            this.label17.Text = " Address:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 321);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(122, 24);
            this.label16.TabIndex = 31;
            this.label16.Text = "Next Of Kin:";
            // 
            // cb_Ward
            // 
            this.cb_Ward.FormattingEnabled = true;
            this.cb_Ward.Items.AddRange(new object[] {
            "WARD 1",
            "WARD 2",
            "WARD 3",
            "WARD 3",
            "WARD 4",
            "WARD 5",
            "WARD 6",
            "WARD 7"});
            this.cb_Ward.Location = new System.Drawing.Point(858, 151);
            this.cb_Ward.Name = "cb_Ward";
            this.cb_Ward.Size = new System.Drawing.Size(144, 32);
            this.cb_Ward.TabIndex = 30;
            // 
            // cb_Folder
            // 
            this.cb_Folder.FormattingEnabled = true;
            this.cb_Folder.Items.AddRange(new object[] {
            "ABTH/PF/0002",
            "ABTH/PF/0003",
            "ABTH/PF/0004",
            "ABTH/PF/0005",
            "ABTH/PF/0006",
            "ABTH/PF/0007"});
            this.cb_Folder.Location = new System.Drawing.Point(559, 151);
            this.cb_Folder.Name = "cb_Folder";
            this.cb_Folder.Size = new System.Drawing.Size(200, 32);
            this.cb_Folder.TabIndex = 29;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(790, 159);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 24);
            this.label15.TabIndex = 28;
            this.label15.Text = "Ward:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(439, 159);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(114, 24);
            this.label14.TabIndex = 27;
            this.label14.Text = "Folder NO:";
            // 
            // tb_PhoneNo
            // 
            this.tb_PhoneNo.Location = new System.Drawing.Point(559, 76);
            this.tb_PhoneNo.Name = "tb_PhoneNo";
            this.tb_PhoneNo.Size = new System.Drawing.Size(200, 29);
            this.tb_PhoneNo.TabIndex = 26;
            // 
            // tb_Address
            // 
            this.tb_Address.Location = new System.Drawing.Point(559, 28);
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(443, 29);
            this.tb_Address.TabIndex = 25;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(414, 79);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(151, 24);
            this.label13.TabIndex = 24;
            this.label13.Text = "Telephone No:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(460, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 24);
            this.label12.TabIndex = 23;
            this.label12.Text = "Address:";
            // 
            // btnFinger
            // 
            this.btnFinger.Location = new System.Drawing.Point(807, 408);
            this.btnFinger.Name = "btnFinger";
            this.btnFinger.Size = new System.Drawing.Size(160, 43);
            this.btnFinger.TabIndex = 22;
            this.btnFinger.Text = "Capture Finger";
            this.btnFinger.UseVisualStyleBackColor = true;
            // 
            // btnPhoto
            // 
            this.btnPhoto.Location = new System.Drawing.Point(431, 408);
            this.btnPhoto.Name = "btnPhoto";
            this.btnPhoto.Size = new System.Drawing.Size(160, 43);
            this.btnPhoto.TabIndex = 21;
            this.btnPhoto.Text = "Capture Photo";
            this.btnPhoto.UseVisualStyleBackColor = true;
            // 
            // PbFinger
            // 
            this.PbFinger.Location = new System.Drawing.Point(794, 229);
            this.PbFinger.Name = "PbFinger";
            this.PbFinger.Size = new System.Drawing.Size(173, 162);
            this.PbFinger.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbFinger.TabIndex = 20;
            this.PbFinger.TabStop = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(750, 120);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 19;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(610, 114);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(134, 24);
            this.label11.TabIndex = 18;
            this.label11.Text = "Unemployed:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(576, 120);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 17;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(455, 119);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 24);
            this.label10.TabIndex = 16;
            this.label10.Text = "Employed:";
            // 
            // PbPhoto
            // 
            this.PbPhoto.Location = new System.Drawing.Point(431, 229);
            this.PbPhoto.Name = "PbPhoto";
            this.PbPhoto.Size = new System.Drawing.Size(160, 162);
            this.PbPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbPhoto.TabIndex = 15;
            this.PbPhoto.TabStop = false;
            // 
            // cb_LocalGvt
            // 
            this.cb_LocalGvt.FormattingEnabled = true;
            this.cb_LocalGvt.Items.AddRange(new object[] {
            "Abakiliki",
            "Izzamgbo",
            "Onicha",
            "Afikpo North",
            "Afikpo South",
            "Ohaozara"});
            this.cb_LocalGvt.Location = new System.Drawing.Point(157, 247);
            this.cb_LocalGvt.Name = "cb_LocalGvt";
            this.cb_LocalGvt.Size = new System.Drawing.Size(121, 32);
            this.cb_LocalGvt.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 247);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 24);
            this.label9.TabIndex = 13;
            this.label9.Text = "Local Govt:";
            // 
            // cb_GenoType
            // 
            this.cb_GenoType.FormattingEnabled = true;
            this.cb_GenoType.Items.AddRange(new object[] {
            "AA",
            "AB",
            "BB",
            "BA",
            "AS",
            "SS"});
            this.cb_GenoType.Location = new System.Drawing.Point(157, 203);
            this.cb_GenoType.Name = "cb_GenoType";
            this.cb_GenoType.Size = new System.Drawing.Size(121, 32);
            this.cb_GenoType.TabIndex = 12;
            // 
            // cb_BloodGp
            // 
            this.cb_BloodGp.FormattingEnabled = true;
            this.cb_BloodGp.Items.AddRange(new object[] {
            "O+",
            "O-",
            "AB",
            "BA",
            "AA",
            "BB"});
            this.cb_BloodGp.Location = new System.Drawing.Point(157, 159);
            this.cb_BloodGp.Name = "cb_BloodGp";
            this.cb_BloodGp.Size = new System.Drawing.Size(121, 32);
            this.cb_BloodGp.TabIndex = 11;
            // 
            // tb_Surname
            // 
            this.tb_Surname.Location = new System.Drawing.Point(157, 124);
            this.tb_Surname.Name = "tb_Surname";
            this.tb_Surname.Size = new System.Drawing.Size(230, 29);
            this.tb_Surname.TabIndex = 10;
            // 
            // tb_Othernames
            // 
            this.tb_Othernames.Location = new System.Drawing.Point(157, 81);
            this.tb_Othernames.Name = "tb_Othernames";
            this.tb_Othernames.Size = new System.Drawing.Size(230, 29);
            this.tb_Othernames.TabIndex = 9;
            // 
            // tb_Firstname
            // 
            this.tb_Firstname.Location = new System.Drawing.Point(157, 46);
            this.tb_Firstname.Name = "tb_Firstname";
            this.tb_Firstname.Size = new System.Drawing.Size(230, 29);
            this.tb_Firstname.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "GenoType:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "BloodGroup:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 129);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "Surname:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Othernames:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(325, 670);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(290, 24);
            this.label19.TabIndex = 5;
            this.label19.Text = "...Healthy State is a Wealthy State.";
            // 
            // Mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.ClientSize = new System.Drawing.Size(1042, 741);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Mainform";
            this.Text = "Ebonyi State Health Insurance Scheme";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbFinger)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbPhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.TextBox tb_nextOfKinT;
        private System.Windows.Forms.TextBox tb_NextOfKinAD;
        private System.Windows.Forms.TextBox tb_NextOfKin;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cb_Ward;
        private System.Windows.Forms.ComboBox cb_Folder;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tb_PhoneNo;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnFinger;
        private System.Windows.Forms.Button btnPhoto;
        private System.Windows.Forms.PictureBox PbFinger;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox PbPhoto;
        private System.Windows.Forms.ComboBox cb_LocalGvt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cb_GenoType;
        private System.Windows.Forms.ComboBox cb_BloodGp;
        private System.Windows.Forms.TextBox tb_Surname;
        private System.Windows.Forms.TextBox tb_Othernames;
        private System.Windows.Forms.TextBox tb_Firstname;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label19;
    }
}

