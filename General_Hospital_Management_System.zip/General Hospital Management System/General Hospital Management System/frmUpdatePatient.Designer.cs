﻿namespace General_Hospital_Management_System
{
    partial class frmUpdatePatient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUpdatePatient));
            this.tbgContact = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbgFullname = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2HtmlLabel15 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tbpatID = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cbNationality = new Guna.UI2.WinForms.Guna2ComboBox();
            this.dtpDateOfBirth = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.cbGender = new Guna.UI2.WinForms.Guna2ComboBox();
            this.tbResidentAd = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbOccupation = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbEmail = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbAge = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbContact = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbMiddlename = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbSurname = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbFirstname = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tbgRelationship = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.btnCapture = new Guna.UI2.WinForms.Guna2Button();
            this.btnUpload = new Guna.UI2.WinForms.Guna2Button();
            this.btnUpdateDetails = new Guna.UI2.WinForms.Guna2Button();
            this.btnCancel = new Guna.UI2.WinForms.Guna2Button();
            this.picUdateDetails = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2HtmlLabel16 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2GroupBox1.SuspendLayout();
            this.guna2GroupBox2.SuspendLayout();
            this.guna2GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picUdateDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // tbgContact
            // 
            this.tbgContact.AutoRoundedCorners = true;
            this.tbgContact.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbgContact.BorderRadius = 13;
            this.tbgContact.BorderThickness = 2;
            this.tbgContact.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbgContact.DefaultText = "";
            this.tbgContact.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbgContact.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbgContact.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbgContact.DisabledState.Parent = this.tbgContact;
            this.tbgContact.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbgContact.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbgContact.FocusedState.Parent = this.tbgContact;
            this.tbgContact.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbgContact.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbgContact.HoverState.Parent = this.tbgContact;
            this.tbgContact.Location = new System.Drawing.Point(186, 95);
            this.tbgContact.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbgContact.Name = "tbgContact";
            this.tbgContact.PasswordChar = '\0';
            this.tbgContact.PlaceholderText = "";
            this.tbgContact.SelectedText = "";
            this.tbgContact.ShadowDecoration.Parent = this.tbgContact;
            this.tbgContact.Size = new System.Drawing.Size(306, 29);
            this.tbgContact.TabIndex = 10;
            this.tbgContact.TextChanged += new System.EventHandler(this.tbgContact_TextChanged);
            this.tbgContact.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbgContact_KeyPress);
            this.tbgContact.Leave += new System.EventHandler(this.tbgContact_Leave);
            // 
            // tbgFullname
            // 
            this.tbgFullname.AutoRoundedCorners = true;
            this.tbgFullname.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbgFullname.BorderRadius = 13;
            this.tbgFullname.BorderThickness = 2;
            this.tbgFullname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbgFullname.DefaultText = "";
            this.tbgFullname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbgFullname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbgFullname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbgFullname.DisabledState.Parent = this.tbgFullname;
            this.tbgFullname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbgFullname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbgFullname.FocusedState.Parent = this.tbgFullname;
            this.tbgFullname.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbgFullname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbgFullname.HoverState.Parent = this.tbgFullname;
            this.tbgFullname.Location = new System.Drawing.Point(186, 57);
            this.tbgFullname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbgFullname.Name = "tbgFullname";
            this.tbgFullname.PasswordChar = '\0';
            this.tbgFullname.PlaceholderText = "";
            this.tbgFullname.SelectedText = "";
            this.tbgFullname.ShadowDecoration.Parent = this.tbgFullname;
            this.tbgFullname.Size = new System.Drawing.Size(306, 29);
            this.tbgFullname.TabIndex = 11;
            this.tbgFullname.TextChanged += new System.EventHandler(this.tbgFullname_TextChanged);
            this.tbgFullname.Leave += new System.EventHandler(this.tbgFullname_Leave);
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.AutoRoundedCorners = true;
            this.guna2GroupBox1.BorderRadius = 155;
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel16);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel15);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel14);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel13);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel12);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel11);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel4);
            this.guna2GroupBox1.Controls.Add(this.tbpatID);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel10);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel9);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel8);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel7);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel6);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel5);
            this.guna2GroupBox1.Controls.Add(this.cbNationality);
            this.guna2GroupBox1.Controls.Add(this.dtpDateOfBirth);
            this.guna2GroupBox1.Controls.Add(this.cbGender);
            this.guna2GroupBox1.Controls.Add(this.tbResidentAd);
            this.guna2GroupBox1.Controls.Add(this.tbOccupation);
            this.guna2GroupBox1.Controls.Add(this.tbEmail);
            this.guna2GroupBox1.Controls.Add(this.tbAge);
            this.guna2GroupBox1.Controls.Add(this.tbContact);
            this.guna2GroupBox1.Controls.Add(this.tbMiddlename);
            this.guna2GroupBox1.Controls.Add(this.tbSurname);
            this.guna2GroupBox1.Controls.Add(this.tbFirstname);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(13, 19);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(657, 312);
            this.guna2GroupBox1.TabIndex = 12;
            this.guna2GroupBox1.Text = "                                                         Update Patient Details";
            // 
            // guna2HtmlLabel15
            // 
            this.guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel15.Location = new System.Drawing.Point(322, 228);
            this.guna2HtmlLabel15.Name = "guna2HtmlLabel15";
            this.guna2HtmlLabel15.Size = new System.Drawing.Size(101, 21);
            this.guna2HtmlLabel15.TabIndex = 39;
            this.guna2HtmlLabel15.Text = "Residence Ad:\r\n";
            // 
            // guna2HtmlLabel14
            // 
            this.guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel14.Location = new System.Drawing.Point(323, 190);
            this.guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            this.guna2HtmlLabel14.Size = new System.Drawing.Size(82, 21);
            this.guna2HtmlLabel14.TabIndex = 38;
            this.guna2HtmlLabel14.Text = "Nationality:";
            // 
            // guna2HtmlLabel13
            // 
            this.guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel13.Location = new System.Drawing.Point(366, 152);
            this.guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            this.guna2HtmlLabel13.Size = new System.Drawing.Size(35, 21);
            this.guna2HtmlLabel13.TabIndex = 37;
            this.guna2HtmlLabel13.Text = "Age:";
            // 
            // guna2HtmlLabel12
            // 
            this.guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel12.Location = new System.Drawing.Point(347, 116);
            this.guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            this.guna2HtmlLabel12.Size = new System.Drawing.Size(58, 21);
            this.guna2HtmlLabel12.TabIndex = 36;
            this.guna2HtmlLabel12.Text = "Gender:";
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(343, 77);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(62, 21);
            this.guna2HtmlLabel11.TabIndex = 35;
            this.guna2HtmlLabel11.Text = "Surname";
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(34, 46);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(68, 21);
            this.guna2HtmlLabel4.TabIndex = 28;
            this.guna2HtmlLabel4.Text = "Patient Id";
            // 
            // tbpatID
            // 
            this.tbpatID.AutoRoundedCorners = true;
            this.tbpatID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbpatID.BorderRadius = 13;
            this.tbpatID.BorderThickness = 2;
            this.tbpatID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbpatID.DefaultText = "";
            this.tbpatID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbpatID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbpatID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbpatID.DisabledState.Parent = this.tbpatID;
            this.tbpatID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbpatID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbpatID.FocusedState.Parent = this.tbpatID;
            this.tbpatID.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbpatID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbpatID.HoverState.Parent = this.tbpatID;
            this.tbpatID.Location = new System.Drawing.Point(105, 42);
            this.tbpatID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbpatID.Name = "tbpatID";
            this.tbpatID.PasswordChar = '\0';
            this.tbpatID.PlaceholderText = "";
            this.tbpatID.SelectedText = "";
            this.tbpatID.ShadowDecoration.Parent = this.tbpatID;
            this.tbpatID.Size = new System.Drawing.Size(210, 29);
            this.tbpatID.TabIndex = 22;
            this.tbpatID.TextChanged += new System.EventHandler(this.tbpatID_TextChanged);
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(57, 265);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(46, 21);
            this.guna2HtmlLabel10.TabIndex = 34;
            this.guna2HtmlLabel10.Text = "Email:";
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(42, 231);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(60, 21);
            this.guna2HtmlLabel9.TabIndex = 33;
            this.guna2HtmlLabel9.Text = "Contact:";
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(15, 195);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(83, 21);
            this.guna2HtmlLabel8.TabIndex = 32;
            this.guna2HtmlLabel8.Text = "Occupation:";
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(3, 156);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(100, 21);
            this.guna2HtmlLabel7.TabIndex = 31;
            this.guna2HtmlLabel7.Text = "Date Of Birth:";
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(15, 116);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(87, 21);
            this.guna2HtmlLabel6.TabIndex = 30;
            this.guna2HtmlLabel6.Text = "Middlename";
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(32, 81);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(70, 21);
            this.guna2HtmlLabel5.TabIndex = 29;
            this.guna2HtmlLabel5.Text = "Firstname";
            // 
            // cbNationality
            // 
            this.cbNationality.AutoRoundedCorners = true;
            this.cbNationality.BackColor = System.Drawing.Color.Transparent;
            this.cbNationality.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbNationality.BorderRadius = 17;
            this.cbNationality.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbNationality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNationality.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbNationality.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbNationality.FocusedState.Parent = this.cbNationality;
            this.cbNationality.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbNationality.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbNationality.HoverState.Parent = this.cbNationality;
            this.cbNationality.ItemHeight = 30;
            this.cbNationality.Items.AddRange(new object[] {
            "",
            "Afghanistan",
            "Albania",
            "Algeria",
            "Andorra",
            "Angola",
            "Anguilla",
            "Antarctica",
            "Argentina",
            "Armenia",
            "Australia",
            "Austria",
            "Azerbaijan",
            "Bahamas",
            "Bahrain",
            "Bangladesh",
            "Barbados",
            "Belarus",
            "Belgium",
            "Benin",
            "Bermuda",
            "Bolivia",
            "Bosnia and Herzegovina",
            "Botswana",
            "Brazil",
            "Brunei",
            "Bulgaria",
            "Burkina Faso",
            "Burma",
            "Burundi",
            "Cambodia",
            "Cameroon",
            "Canada",
            "Cape Verde",
            "Central African Republic",
            "Chad",
            "Chile",
            "China",
            "Colombia",
            "Comoros",
            "Congo, Democratic Republic",
            "Congo, Republic",
            "Costa Rica",
            "Cote d\'Ivoire",
            "Croatia",
            "Cuba",
            "Cyprus",
            "Czech Republic",
            "Denmark",
            "Dominica",
            "Dominican Republic",
            "Ecuador",
            "Egypt",
            "El Salvador",
            "Equatorial Guinea",
            "Eritrea",
            "Estonia",
            "Ethiopia",
            "Faroe Islands",
            "Fiji",
            "Finland",
            "France",
            "Gabon",
            "Gambia",
            "Georgia",
            "Germany",
            "Ghana",
            "Gibraltar",
            "Greece",
            "Guam",
            "Guatemala",
            "Guinea",
            "Guinea-Bissau",
            "Haiti",
            "Honduras",
            "Hong Kong",
            "Hungary",
            "Iceland",
            "India",
            "Indonesia",
            "Iran",
            "Iraq",
            "Ireland",
            "Isle of Man",
            "Israel",
            "Italy",
            "Jamaica",
            "Japan",
            "Jersey",
            "Jordan",
            "Juan de Nova Island",
            "Kazakhstan",
            "Kenya",
            "North Korea",
            "South Korea",
            "Kuwait",
            "Kyrgyzstan",
            "Latvia",
            "Lebanon",
            "Lesotho",
            "Liberia",
            "Libya",
            "Liechtenstein",
            "Lithuania",
            "Luxembourg",
            "Macedonia",
            "Madagascar",
            "Malawi",
            "Malaysia",
            "Maldives",
            "Mali",
            "Malta",
            "Mauritania",
            "Mauritius",
            "Mexico",
            "Moldova",
            "Mongolia",
            "Montserrat",
            "Morocco",
            "Mozambique",
            "Namibia",
            "Nepal",
            "Netherlands",
            "Netherlands Antilles",
            "New Caledonia",
            "New Zealand",
            "Nicaragua",
            "Niger",
            "Nigeria",
            "Niue",
            "Norway",
            "Oman",
            "Pakistan",
            "Panama",
            "Paraguay",
            "Peru",
            "Philippines",
            "Pitcairn Islands",
            "Poland",
            "Portugal",
            "Puerto Rico",
            "Qatar",
            "Romania",
            "Russia",
            "Rwanda",
            "Samoa",
            "San Marino",
            "SaoTome and Principe",
            "Saudi Arabia",
            "Senegal",
            "Serbia and Montenegro",
            "Seychelles",
            "Sierra Leone",
            "Singapore",
            "Slovakia",
            "Slovenia",
            "Solomon Islands",
            "Somalia",
            "South Africa",
            "Spain",
            "Sri Lanka",
            "Sudan",
            "Swaziland",
            "Sweden",
            "Switzerland",
            "Syria",
            "Taiwan",
            "Tanzania",
            "Thailand",
            "Togo",
            "Trinidad and Tobago",
            "Tunisia",
            "Turkey",
            "Turkmenistan",
            "Uganda",
            "Ukraine",
            "United Arab Emirates",
            "United Kingdom",
            "United States",
            "Uruguay",
            "Uzbekistan",
            "Venezuela",
            "Vietnam",
            "Virgin Islands",
            "Yemen",
            "Zambia",
            "Zimbabwe"});
            this.cbNationality.ItemsAppearance.Parent = this.cbNationality;
            this.cbNationality.Location = new System.Drawing.Point(421, 180);
            this.cbNationality.Name = "cbNationality";
            this.cbNationality.ShadowDecoration.Parent = this.cbNationality;
            this.cbNationality.Size = new System.Drawing.Size(201, 36);
            this.cbNationality.TabIndex = 27;
            // 
            // dtpDateOfBirth
            // 
            this.dtpDateOfBirth.AutoRoundedCorners = true;
            this.dtpDateOfBirth.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.dtpDateOfBirth.BorderRadius = 14;
            this.dtpDateOfBirth.BorderThickness = 1;
            this.dtpDateOfBirth.CheckedState.Parent = this.dtpDateOfBirth;
            this.dtpDateOfBirth.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.dtpDateOfBirth.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.dtpDateOfBirth.ForeColor = System.Drawing.Color.White;
            this.dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateOfBirth.HoverState.Parent = this.dtpDateOfBirth;
            this.dtpDateOfBirth.Location = new System.Drawing.Point(105, 152);
            this.dtpDateOfBirth.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpDateOfBirth.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpDateOfBirth.Name = "dtpDateOfBirth";
            this.dtpDateOfBirth.ShadowDecoration.Parent = this.dtpDateOfBirth;
            this.dtpDateOfBirth.Size = new System.Drawing.Size(210, 30);
            this.dtpDateOfBirth.TabIndex = 26;
            this.dtpDateOfBirth.Value = new System.DateTime(2021, 6, 24, 22, 49, 57, 542);
            this.dtpDateOfBirth.ValueChanged += new System.EventHandler(this.dtpDateOfBirth_ValueChanged);
            // 
            // cbGender
            // 
            this.cbGender.AutoRoundedCorners = true;
            this.cbGender.BackColor = System.Drawing.Color.Transparent;
            this.cbGender.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbGender.BorderRadius = 17;
            this.cbGender.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGender.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbGender.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbGender.FocusedState.Parent = this.cbGender;
            this.cbGender.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbGender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbGender.HoverState.Parent = this.cbGender;
            this.cbGender.ItemHeight = 30;
            this.cbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cbGender.ItemsAppearance.Parent = this.cbGender;
            this.cbGender.Location = new System.Drawing.Point(421, 109);
            this.cbGender.Name = "cbGender";
            this.cbGender.ShadowDecoration.Parent = this.cbGender;
            this.cbGender.Size = new System.Drawing.Size(201, 36);
            this.cbGender.TabIndex = 25;
            // 
            // tbResidentAd
            // 
            this.tbResidentAd.AutoRoundedCorners = true;
            this.tbResidentAd.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbResidentAd.BorderRadius = 13;
            this.tbResidentAd.BorderThickness = 2;
            this.tbResidentAd.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbResidentAd.DefaultText = "";
            this.tbResidentAd.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbResidentAd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbResidentAd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbResidentAd.DisabledState.Parent = this.tbResidentAd;
            this.tbResidentAd.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbResidentAd.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbResidentAd.FocusedState.Parent = this.tbResidentAd;
            this.tbResidentAd.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbResidentAd.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbResidentAd.HoverState.Parent = this.tbResidentAd;
            this.tbResidentAd.Location = new System.Drawing.Point(421, 223);
            this.tbResidentAd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbResidentAd.Name = "tbResidentAd";
            this.tbResidentAd.PasswordChar = '\0';
            this.tbResidentAd.PlaceholderText = "";
            this.tbResidentAd.SelectedText = "";
            this.tbResidentAd.ShadowDecoration.Parent = this.tbResidentAd;
            this.tbResidentAd.Size = new System.Drawing.Size(201, 29);
            this.tbResidentAd.TabIndex = 24;
            this.tbResidentAd.TextChanged += new System.EventHandler(this.tbResidentAd_TextChanged);
            // 
            // tbOccupation
            // 
            this.tbOccupation.AutoRoundedCorners = true;
            this.tbOccupation.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbOccupation.BorderRadius = 13;
            this.tbOccupation.BorderThickness = 2;
            this.tbOccupation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbOccupation.DefaultText = "";
            this.tbOccupation.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbOccupation.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbOccupation.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbOccupation.DisabledState.Parent = this.tbOccupation;
            this.tbOccupation.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbOccupation.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbOccupation.FocusedState.Parent = this.tbOccupation;
            this.tbOccupation.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbOccupation.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbOccupation.HoverState.Parent = this.tbOccupation;
            this.tbOccupation.Location = new System.Drawing.Point(105, 191);
            this.tbOccupation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbOccupation.Name = "tbOccupation";
            this.tbOccupation.PasswordChar = '\0';
            this.tbOccupation.PlaceholderText = "";
            this.tbOccupation.SelectedText = "";
            this.tbOccupation.ShadowDecoration.Parent = this.tbOccupation;
            this.tbOccupation.Size = new System.Drawing.Size(210, 29);
            this.tbOccupation.TabIndex = 21;
            this.tbOccupation.TextChanged += new System.EventHandler(this.tbOccupation_TextChanged);
            this.tbOccupation.Leave += new System.EventHandler(this.tbOccupation_Leave);
            // 
            // tbEmail
            // 
            this.tbEmail.AutoRoundedCorners = true;
            this.tbEmail.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbEmail.BorderRadius = 13;
            this.tbEmail.BorderThickness = 2;
            this.tbEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbEmail.DefaultText = "";
            this.tbEmail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbEmail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbEmail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbEmail.DisabledState.Parent = this.tbEmail;
            this.tbEmail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbEmail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbEmail.FocusedState.Parent = this.tbEmail;
            this.tbEmail.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbEmail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbEmail.HoverState.Parent = this.tbEmail;
            this.tbEmail.Location = new System.Drawing.Point(105, 265);
            this.tbEmail.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.PasswordChar = '\0';
            this.tbEmail.PlaceholderText = "";
            this.tbEmail.SelectedText = "";
            this.tbEmail.ShadowDecoration.Parent = this.tbEmail;
            this.tbEmail.Size = new System.Drawing.Size(466, 29);
            this.tbEmail.TabIndex = 20;
            // 
            // tbAge
            // 
            this.tbAge.AutoRoundedCorners = true;
            this.tbAge.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbAge.BorderRadius = 13;
            this.tbAge.BorderThickness = 2;
            this.tbAge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbAge.DefaultText = "";
            this.tbAge.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbAge.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbAge.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbAge.DisabledState.Parent = this.tbAge;
            this.tbAge.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbAge.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbAge.FocusedState.Parent = this.tbAge;
            this.tbAge.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbAge.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbAge.HoverState.Parent = this.tbAge;
            this.tbAge.Location = new System.Drawing.Point(421, 148);
            this.tbAge.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbAge.Name = "tbAge";
            this.tbAge.PasswordChar = '\0';
            this.tbAge.PlaceholderText = "";
            this.tbAge.SelectedText = "";
            this.tbAge.ShadowDecoration.Parent = this.tbAge;
            this.tbAge.Size = new System.Drawing.Size(118, 29);
            this.tbAge.TabIndex = 19;
            // 
            // tbContact
            // 
            this.tbContact.AutoRoundedCorners = true;
            this.tbContact.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbContact.BorderRadius = 13;
            this.tbContact.BorderThickness = 2;
            this.tbContact.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbContact.DefaultText = "";
            this.tbContact.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbContact.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbContact.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbContact.DisabledState.Parent = this.tbContact;
            this.tbContact.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbContact.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbContact.FocusedState.Parent = this.tbContact;
            this.tbContact.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbContact.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbContact.HoverState.Parent = this.tbContact;
            this.tbContact.Location = new System.Drawing.Point(105, 228);
            this.tbContact.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbContact.Name = "tbContact";
            this.tbContact.PasswordChar = '\0';
            this.tbContact.PlaceholderText = "";
            this.tbContact.SelectedText = "";
            this.tbContact.ShadowDecoration.Parent = this.tbContact;
            this.tbContact.Size = new System.Drawing.Size(210, 29);
            this.tbContact.TabIndex = 18;
            this.tbContact.TextChanged += new System.EventHandler(this.tbContact_TextChanged);
            this.tbContact.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbContact_KeyPress);
            this.tbContact.Leave += new System.EventHandler(this.tbContact_Leave);
            // 
            // tbMiddlename
            // 
            this.tbMiddlename.AutoRoundedCorners = true;
            this.tbMiddlename.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbMiddlename.BorderRadius = 13;
            this.tbMiddlename.BorderThickness = 2;
            this.tbMiddlename.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbMiddlename.DefaultText = "";
            this.tbMiddlename.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbMiddlename.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbMiddlename.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbMiddlename.DisabledState.Parent = this.tbMiddlename;
            this.tbMiddlename.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbMiddlename.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbMiddlename.FocusedState.Parent = this.tbMiddlename;
            this.tbMiddlename.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbMiddlename.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbMiddlename.HoverState.Parent = this.tbMiddlename;
            this.tbMiddlename.Location = new System.Drawing.Point(105, 116);
            this.tbMiddlename.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbMiddlename.Name = "tbMiddlename";
            this.tbMiddlename.PasswordChar = '\0';
            this.tbMiddlename.PlaceholderText = "";
            this.tbMiddlename.SelectedText = "";
            this.tbMiddlename.ShadowDecoration.Parent = this.tbMiddlename;
            this.tbMiddlename.Size = new System.Drawing.Size(210, 29);
            this.tbMiddlename.TabIndex = 17;
            // 
            // tbSurname
            // 
            this.tbSurname.AutoRoundedCorners = true;
            this.tbSurname.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbSurname.BorderRadius = 13;
            this.tbSurname.BorderThickness = 2;
            this.tbSurname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSurname.DefaultText = "";
            this.tbSurname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbSurname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbSurname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbSurname.DisabledState.Parent = this.tbSurname;
            this.tbSurname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbSurname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbSurname.FocusedState.Parent = this.tbSurname;
            this.tbSurname.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbSurname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbSurname.HoverState.Parent = this.tbSurname;
            this.tbSurname.Location = new System.Drawing.Point(421, 73);
            this.tbSurname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbSurname.Name = "tbSurname";
            this.tbSurname.PasswordChar = '\0';
            this.tbSurname.PlaceholderText = "";
            this.tbSurname.SelectedText = "";
            this.tbSurname.ShadowDecoration.Parent = this.tbSurname;
            this.tbSurname.Size = new System.Drawing.Size(201, 29);
            this.tbSurname.TabIndex = 16;
            this.tbSurname.TextChanged += new System.EventHandler(this.tbSurname_TextChanged);
            this.tbSurname.Leave += new System.EventHandler(this.tbSurname_Leave);
            // 
            // tbFirstname
            // 
            this.tbFirstname.AutoRoundedCorners = true;
            this.tbFirstname.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbFirstname.BorderRadius = 13;
            this.tbFirstname.BorderThickness = 2;
            this.tbFirstname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbFirstname.DefaultText = "";
            this.tbFirstname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbFirstname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbFirstname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbFirstname.DisabledState.Parent = this.tbFirstname;
            this.tbFirstname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbFirstname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbFirstname.FocusedState.Parent = this.tbFirstname;
            this.tbFirstname.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbFirstname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbFirstname.HoverState.Parent = this.tbFirstname;
            this.tbFirstname.Location = new System.Drawing.Point(105, 79);
            this.tbFirstname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbFirstname.Name = "tbFirstname";
            this.tbFirstname.PasswordChar = '\0';
            this.tbFirstname.PlaceholderText = "";
            this.tbFirstname.SelectedText = "";
            this.tbFirstname.ShadowDecoration.Parent = this.tbFirstname;
            this.tbFirstname.Size = new System.Drawing.Size(210, 29);
            this.tbFirstname.TabIndex = 15;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.AutoRoundedCorners = true;
            this.guna2GroupBox2.BorderRadius = 92;
            this.guna2GroupBox2.Controls.Add(this.guna2HtmlLabel3);
            this.guna2GroupBox2.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GroupBox2.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GroupBox2.Controls.Add(this.tbgRelationship);
            this.guna2GroupBox2.Controls.Add(this.tbgFullname);
            this.guna2GroupBox2.Controls.Add(this.tbgContact);
            this.guna2GroupBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox2.Location = new System.Drawing.Point(13, 337);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.ShadowDecoration.Parent = this.guna2GroupBox2;
            this.guna2GroupBox2.Size = new System.Drawing.Size(657, 187);
            this.guna2GroupBox2.TabIndex = 13;
            this.guna2GroupBox2.Text = "                                                                 Gaurdian Details" +
    "";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(15, 132);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(169, 21);
            this.guna2HtmlLabel3.TabIndex = 15;
            this.guna2HtmlLabel3.Text = "Relationship with Patient";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(120, 100);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(55, 21);
            this.guna2HtmlLabel2.TabIndex = 14;
            this.guna2HtmlLabel2.Text = "Contact";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(120, 62);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(64, 21);
            this.guna2HtmlLabel1.TabIndex = 13;
            this.guna2HtmlLabel1.Text = "Fullname";
            // 
            // tbgRelationship
            // 
            this.tbgRelationship.AutoRoundedCorners = true;
            this.tbgRelationship.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbgRelationship.BorderRadius = 13;
            this.tbgRelationship.BorderThickness = 2;
            this.tbgRelationship.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbgRelationship.DefaultText = "";
            this.tbgRelationship.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbgRelationship.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbgRelationship.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbgRelationship.DisabledState.Parent = this.tbgRelationship;
            this.tbgRelationship.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbgRelationship.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbgRelationship.FocusedState.Parent = this.tbgRelationship;
            this.tbgRelationship.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbgRelationship.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbgRelationship.HoverState.Parent = this.tbgRelationship;
            this.tbgRelationship.Location = new System.Drawing.Point(186, 132);
            this.tbgRelationship.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbgRelationship.Name = "tbgRelationship";
            this.tbgRelationship.PasswordChar = '\0';
            this.tbgRelationship.PlaceholderText = "";
            this.tbgRelationship.SelectedText = "";
            this.tbgRelationship.ShadowDecoration.Parent = this.tbgRelationship;
            this.tbgRelationship.Size = new System.Drawing.Size(306, 29);
            this.tbgRelationship.TabIndex = 12;
            this.tbgRelationship.TextChanged += new System.EventHandler(this.tbgRelationship_TextChanged);
            this.tbgRelationship.Leave += new System.EventHandler(this.tbgRelationship_Leave);
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.Controls.Add(this.btnCapture);
            this.guna2GroupBox3.Controls.Add(this.btnUpload);
            this.guna2GroupBox3.Controls.Add(this.picUdateDetails);
            this.guna2GroupBox3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox3.Location = new System.Drawing.Point(676, 13);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.ShadowDecoration.Parent = this.guna2GroupBox3;
            this.guna2GroupBox3.Size = new System.Drawing.Size(218, 287);
            this.guna2GroupBox3.TabIndex = 14;
            this.guna2GroupBox3.Text = "Upload/Capture   Image";
            // 
            // btnCapture
            // 
            this.btnCapture.AutoRoundedCorners = true;
            this.btnCapture.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCapture.BorderRadius = 14;
            this.btnCapture.BorderThickness = 2;
            this.btnCapture.CheckedState.Parent = this.btnCapture;
            this.btnCapture.CustomImages.Parent = this.btnCapture;
            this.btnCapture.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnCapture.ForeColor = System.Drawing.Color.White;
            this.btnCapture.HoverState.Parent = this.btnCapture;
            this.btnCapture.Location = new System.Drawing.Point(117, 248);
            this.btnCapture.Name = "btnCapture";
            this.btnCapture.ShadowDecoration.Parent = this.btnCapture;
            this.btnCapture.Size = new System.Drawing.Size(97, 30);
            this.btnCapture.TabIndex = 2;
            this.btnCapture.Text = "Capture";
            // 
            // btnUpload
            // 
            this.btnUpload.AutoRoundedCorners = true;
            this.btnUpload.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnUpload.BorderRadius = 14;
            this.btnUpload.BorderThickness = 2;
            this.btnUpload.CheckedState.Parent = this.btnUpload;
            this.btnUpload.CustomImages.Parent = this.btnUpload;
            this.btnUpload.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnUpload.ForeColor = System.Drawing.Color.White;
            this.btnUpload.HoverState.Parent = this.btnUpload;
            this.btnUpload.Location = new System.Drawing.Point(14, 248);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.ShadowDecoration.Parent = this.btnUpload;
            this.btnUpload.Size = new System.Drawing.Size(97, 30);
            this.btnUpload.TabIndex = 1;
            this.btnUpload.Text = "UploadImage";
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnUpdateDetails
            // 
            this.btnUpdateDetails.AutoRoundedCorners = true;
            this.btnUpdateDetails.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnUpdateDetails.BorderRadius = 21;
            this.btnUpdateDetails.BorderThickness = 2;
            this.btnUpdateDetails.CheckedState.Parent = this.btnUpdateDetails;
            this.btnUpdateDetails.CustomImages.Parent = this.btnUpdateDetails;
            this.btnUpdateDetails.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnUpdateDetails.ForeColor = System.Drawing.Color.White;
            this.btnUpdateDetails.HoverState.Parent = this.btnUpdateDetails;
            this.btnUpdateDetails.Location = new System.Drawing.Point(675, 393);
            this.btnUpdateDetails.Name = "btnUpdateDetails";
            this.btnUpdateDetails.ShadowDecoration.Parent = this.btnUpdateDetails;
            this.btnUpdateDetails.Size = new System.Drawing.Size(108, 45);
            this.btnUpdateDetails.TabIndex = 15;
            this.btnUpdateDetails.Text = "Update Details";
            this.btnUpdateDetails.Click += new System.EventHandler(this.btnUpdateDetails_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.AutoRoundedCorners = true;
            this.btnCancel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCancel.BorderRadius = 21;
            this.btnCancel.BorderThickness = 2;
            this.btnCancel.CheckedState.Parent = this.btnCancel;
            this.btnCancel.CustomImages.Parent = this.btnCancel;
            this.btnCancel.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.HoverState.Parent = this.btnCancel;
            this.btnCancel.Location = new System.Drawing.Point(786, 393);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.ShadowDecoration.Parent = this.btnCancel;
            this.btnCancel.Size = new System.Drawing.Size(122, 45);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // picUdateDetails
            // 
            this.picUdateDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picUdateDetails.Image = global::General_Hospital_Management_System.Properties.Resources.index1;
            this.picUdateDetails.Location = new System.Drawing.Point(17, 55);
            this.picUdateDetails.Name = "picUdateDetails";
            this.picUdateDetails.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.picUdateDetails.ShadowDecoration.Parent = this.picUdateDetails;
            this.picUdateDetails.Size = new System.Drawing.Size(183, 172);
            this.picUdateDetails.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picUdateDetails.TabIndex = 0;
            this.picUdateDetails.TabStop = false;
            // 
            // guna2HtmlLabel16
            // 
            this.guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel16.Location = new System.Drawing.Point(544, 152);
            this.guna2HtmlLabel16.Name = "guna2HtmlLabel16";
            this.guna2HtmlLabel16.Size = new System.Drawing.Size(42, 21);
            this.guna2HtmlLabel16.TabIndex = 40;
            this.guna2HtmlLabel16.Text = "Years";
            // 
            // frmUpdatePatient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(924, 557);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnUpdateDetails);
            this.Controls.Add(this.guna2GroupBox3);
            this.Controls.Add(this.guna2GroupBox2);
            this.Controls.Add(this.guna2GroupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmUpdatePatient";
            this.Text = "        Update Patient  General Hospital Management Solution (GHMS).";
            this.Load += new System.EventHandler(this.frmUpdatePatient_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.guna2GroupBox2.ResumeLayout(false);
            this.guna2GroupBox2.PerformLayout();
            this.guna2GroupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picUdateDetails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2TextBox tbgContact;
        private Guna.UI2.WinForms.Guna2TextBox tbgFullname;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel15;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2ComboBox cbNationality;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpDateOfBirth;
        private Guna.UI2.WinForms.Guna2ComboBox cbGender;
        private Guna.UI2.WinForms.Guna2TextBox tbResidentAd;
        private Guna.UI2.WinForms.Guna2TextBox tbpatID;
        private Guna.UI2.WinForms.Guna2TextBox tbOccupation;
        private Guna.UI2.WinForms.Guna2TextBox tbEmail;
        private Guna.UI2.WinForms.Guna2TextBox tbAge;
        private Guna.UI2.WinForms.Guna2TextBox tbContact;
        private Guna.UI2.WinForms.Guna2TextBox tbMiddlename;
        private Guna.UI2.WinForms.Guna2TextBox tbSurname;
        private Guna.UI2.WinForms.Guna2TextBox tbFirstname;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox tbgRelationship;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2Button btnUpload;
        private Guna.UI2.WinForms.Guna2CirclePictureBox picUdateDetails;
        private Guna.UI2.WinForms.Guna2Button btnCapture;
        private Guna.UI2.WinForms.Guna2Button btnUpdateDetails;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel16;
    }
}