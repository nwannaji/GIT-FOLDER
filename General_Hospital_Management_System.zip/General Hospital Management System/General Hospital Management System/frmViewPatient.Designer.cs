﻿namespace General_Hospital_Management_System
{
    partial class frmViewPatient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmViewPatient));
            this.tbpatFullname = new System.Windows.Forms.TextBox();
            this.tbpatPhoneNumber = new System.Windows.Forms.TextBox();
            this.tbResidenceAd = new System.Windows.Forms.TextBox();
            this.tbEmailAddress = new System.Windows.Forms.TextBox();
            this.tbOccupation = new System.Windows.Forms.TextBox();
            this.tbCountry = new System.Windows.Forms.TextBox();
            this.tbRefName = new System.Windows.Forms.TextBox();
            this.tbRefPhone = new System.Windows.Forms.TextBox();
            this.picBoxVpat = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnViewPatient = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnViewPatVitals = new System.Windows.Forms.Button();
            this.btnupdatePat = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxVpat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tbpatFullname
            // 
            this.tbpatFullname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpatFullname.Location = new System.Drawing.Point(162, 49);
            this.tbpatFullname.Name = "tbpatFullname";
            this.tbpatFullname.Size = new System.Drawing.Size(305, 26);
            this.tbpatFullname.TabIndex = 0;
            // 
            // tbpatPhoneNumber
            // 
            this.tbpatPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpatPhoneNumber.Location = new System.Drawing.Point(162, 80);
            this.tbpatPhoneNumber.Name = "tbpatPhoneNumber";
            this.tbpatPhoneNumber.Size = new System.Drawing.Size(305, 26);
            this.tbpatPhoneNumber.TabIndex = 1;
            // 
            // tbResidenceAd
            // 
            this.tbResidenceAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbResidenceAd.Location = new System.Drawing.Point(162, 112);
            this.tbResidenceAd.Multiline = true;
            this.tbResidenceAd.Name = "tbResidenceAd";
            this.tbResidenceAd.Size = new System.Drawing.Size(305, 30);
            this.tbResidenceAd.TabIndex = 2;
            // 
            // tbEmailAddress
            // 
            this.tbEmailAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbEmailAddress.Location = new System.Drawing.Point(162, 148);
            this.tbEmailAddress.Name = "tbEmailAddress";
            this.tbEmailAddress.Size = new System.Drawing.Size(305, 26);
            this.tbEmailAddress.TabIndex = 3;
            // 
            // tbOccupation
            // 
            this.tbOccupation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOccupation.Location = new System.Drawing.Point(623, 49);
            this.tbOccupation.Name = "tbOccupation";
            this.tbOccupation.Size = new System.Drawing.Size(208, 26);
            this.tbOccupation.TabIndex = 4;
            // 
            // tbCountry
            // 
            this.tbCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCountry.Location = new System.Drawing.Point(623, 79);
            this.tbCountry.Name = "tbCountry";
            this.tbCountry.Size = new System.Drawing.Size(208, 26);
            this.tbCountry.TabIndex = 5;
            // 
            // tbRefName
            // 
            this.tbRefName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRefName.Location = new System.Drawing.Point(623, 110);
            this.tbRefName.Name = "tbRefName";
            this.tbRefName.Size = new System.Drawing.Size(208, 26);
            this.tbRefName.TabIndex = 6;
            // 
            // tbRefPhone
            // 
            this.tbRefPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRefPhone.Location = new System.Drawing.Point(623, 141);
            this.tbRefPhone.Name = "tbRefPhone";
            this.tbRefPhone.Size = new System.Drawing.Size(208, 26);
            this.tbRefPhone.TabIndex = 7;
            // 
            // picBoxVpat
            // 
            this.picBoxVpat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picBoxVpat.Location = new System.Drawing.Point(838, 49);
            this.picBoxVpat.Name = "picBoxVpat";
            this.picBoxVpat.Size = new System.Drawing.Size(154, 158);
            this.picBoxVpat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxVpat.TabIndex = 8;
            this.picBoxVpat.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(39, 226);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(953, 243);
            this.dataGridView1.TabIndex = 9;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // btnViewPatient
            // 
            this.btnViewPatient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnViewPatient.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnViewPatient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewPatient.Location = new System.Drawing.Point(741, 475);
            this.btnViewPatient.Name = "btnViewPatient";
            this.btnViewPatient.Size = new System.Drawing.Size(90, 33);
            this.btnViewPatient.TabIndex = 10;
            this.btnViewPatient.Text = "Close\r\n";
            this.btnViewPatient.UseVisualStyleBackColor = false;
            this.btnViewPatient.Click += new System.EventHandler(this.btnViewPatient_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Patient\'s Fullname:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 20);
            this.label2.TabIndex = 12;
            this.label2.Text = "Phone Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "Residence Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(528, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Occupation:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(553, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Country:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(489, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 20);
            this.label6.TabIndex = 16;
            this.label6.Text = "Reference Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(475, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(147, 20);
            this.label7.TabIndex = 17;
            this.label7.Text = "Reference Phone #";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(47, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 20);
            this.label8.TabIndex = 18;
            this.label8.Text = "Email Address:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(888, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 16);
            this.label9.TabIndex = 19;
            this.label9.Text = "getID";
            // 
            // btnViewPatVitals
            // 
            this.btnViewPatVitals.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnViewPatVitals.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewPatVitals.Location = new System.Drawing.Point(684, 184);
            this.btnViewPatVitals.Name = "btnViewPatVitals";
            this.btnViewPatVitals.Size = new System.Drawing.Size(148, 36);
            this.btnViewPatVitals.TabIndex = 20;
            this.btnViewPatVitals.Text = "View Patient Vitals";
            this.btnViewPatVitals.UseVisualStyleBackColor = true;
            this.btnViewPatVitals.Click += new System.EventHandler(this.btnViewPatVitals_Click);
            // 
            // btnupdatePat
            // 
            this.btnupdatePat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnupdatePat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatePat.Location = new System.Drawing.Point(162, 184);
            this.btnupdatePat.Name = "btnupdatePat";
            this.btnupdatePat.Size = new System.Drawing.Size(111, 36);
            this.btnupdatePat.TabIndex = 21;
            this.btnupdatePat.Text = "Update Patient";
            this.btnupdatePat.UseVisualStyleBackColor = true;
            this.btnupdatePat.Click += new System.EventHandler(this.btnupdatePat_Click);
            // 
            // frmViewPatient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1029, 538);
            this.Controls.Add(this.btnupdatePat);
            this.Controls.Add(this.btnViewPatVitals);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnViewPatient);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.picBoxVpat);
            this.Controls.Add(this.tbRefPhone);
            this.Controls.Add(this.tbRefName);
            this.Controls.Add(this.tbCountry);
            this.Controls.Add(this.tbOccupation);
            this.Controls.Add(this.tbEmailAddress);
            this.Controls.Add(this.tbResidenceAd);
            this.Controls.Add(this.tbpatPhoneNumber);
            this.Controls.Add(this.tbpatFullname);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmViewPatient";
            this.Text = "View Patient  GHMS";
            this.Load += new System.EventHandler(this.frmViewPatient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxVpat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbpatFullname;
        private System.Windows.Forms.TextBox tbpatPhoneNumber;
        private System.Windows.Forms.TextBox tbResidenceAd;
        private System.Windows.Forms.TextBox tbEmailAddress;
        private System.Windows.Forms.TextBox tbOccupation;
        private System.Windows.Forms.TextBox tbCountry;
        private System.Windows.Forms.TextBox tbRefName;
        private System.Windows.Forms.TextBox tbRefPhone;
        private System.Windows.Forms.PictureBox picBoxVpat;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnViewPatient;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnViewPatVitals;
        private System.Windows.Forms.Button btnupdatePat;
    }
}