﻿namespace General_Hospital_Management_System
{
    partial class frmFemaleWard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFemaleWard));
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.btnReadWard = new Guna.UI2.WinForms.Guna2Button();
            this.tbpatId = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tbNOFpatients = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbfpBill = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbWardName = new Guna.UI2.WinForms.Guna2ComboBox();
            this.btnCancel = new Guna.UI2.WinForms.Guna2Button();
            this.btnSave = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.AutoRoundedCorners = true;
            this.guna2GroupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2GroupBox1.BorderRadius = 151;
            this.guna2GroupBox1.Controls.Add(this.btnReadWard);
            this.guna2GroupBox1.Controls.Add(this.tbpatId);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel4);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel3);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GroupBox1.Controls.Add(this.tbNOFpatients);
            this.guna2GroupBox1.Controls.Add(this.tbfpBill);
            this.guna2GroupBox1.Controls.Add(this.cbWardName);
            this.guna2GroupBox1.Controls.Add(this.btnCancel);
            this.guna2GroupBox1.Controls.Add(this.btnSave);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(15, 16);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(497, 305);
            this.guna2GroupBox1.TabIndex = 1;
            this.guna2GroupBox1.Text = "                                                  Female    Ward";
            // 
            // btnReadWard
            // 
            this.btnReadWard.AutoRoundedCorners = true;
            this.btnReadWard.BackColor = System.Drawing.Color.Transparent;
            this.btnReadWard.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnReadWard.BorderRadius = 14;
            this.btnReadWard.BorderThickness = 2;
            this.btnReadWard.CheckedState.Parent = this.btnReadWard;
            this.btnReadWard.CustomImages.Parent = this.btnReadWard;
            this.btnReadWard.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnReadWard.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnReadWard.ForeColor = System.Drawing.Color.White;
            this.btnReadWard.HoverState.Parent = this.btnReadWard;
            this.btnReadWard.Location = new System.Drawing.Point(194, 256);
            this.btnReadWard.Name = "btnReadWard";
            this.btnReadWard.ShadowDecoration.Parent = this.btnReadWard;
            this.btnReadWard.Size = new System.Drawing.Size(103, 31);
            this.btnReadWard.TabIndex = 19;
            this.btnReadWard.Text = "Read";
            this.btnReadWard.Click += new System.EventHandler(this.btnReadWard_Click);
            // 
            // tbpatId
            // 
            this.tbpatId.AutoRoundedCorners = true;
            this.tbpatId.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbpatId.BorderRadius = 16;
            this.tbpatId.BorderThickness = 2;
            this.tbpatId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbpatId.DefaultText = "";
            this.tbpatId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbpatId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbpatId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbpatId.DisabledState.Parent = this.tbpatId;
            this.tbpatId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbpatId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbpatId.FocusedState.Parent = this.tbpatId;
            this.tbpatId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpatId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbpatId.HoverState.Parent = this.tbpatId;
            this.tbpatId.Location = new System.Drawing.Point(151, 64);
            this.tbpatId.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbpatId.Name = "tbpatId";
            this.tbpatId.PasswordChar = '\0';
            this.tbpatId.PlaceholderText = "";
            this.tbpatId.SelectedText = "";
            this.tbpatId.ShadowDecoration.Parent = this.tbpatId;
            this.tbpatId.Size = new System.Drawing.Size(288, 35);
            this.tbpatId.TabIndex = 18;
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(77, 68);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(68, 21);
            this.guna2HtmlLabel4.TabIndex = 17;
            this.guna2HtmlLabel4.Text = "Patient Id";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(67, 192);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel3.TabIndex = 15;
            this.guna2HtmlLabel3.Text = "Patient Bill";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(10, 152);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(136, 21);
            this.guna2HtmlLabel2.TabIndex = 14;
            this.guna2HtmlLabel2.Text = "Number Of Patients";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(62, 111);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(84, 21);
            this.guna2HtmlLabel1.TabIndex = 13;
            this.guna2HtmlLabel1.Text = "Ward Name";
            // 
            // tbNOFpatients
            // 
            this.tbNOFpatients.AutoRoundedCorners = true;
            this.tbNOFpatients.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbNOFpatients.BorderRadius = 16;
            this.tbNOFpatients.BorderThickness = 2;
            this.tbNOFpatients.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbNOFpatients.DefaultText = "";
            this.tbNOFpatients.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbNOFpatients.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbNOFpatients.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbNOFpatients.DisabledState.Parent = this.tbNOFpatients;
            this.tbNOFpatients.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbNOFpatients.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbNOFpatients.FocusedState.Parent = this.tbNOFpatients;
            this.tbNOFpatients.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNOFpatients.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbNOFpatients.HoverState.Parent = this.tbNOFpatients;
            this.tbNOFpatients.Location = new System.Drawing.Point(151, 148);
            this.tbNOFpatients.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbNOFpatients.Name = "tbNOFpatients";
            this.tbNOFpatients.PasswordChar = '\0';
            this.tbNOFpatients.PlaceholderText = "";
            this.tbNOFpatients.SelectedText = "";
            this.tbNOFpatients.ShadowDecoration.Parent = this.tbNOFpatients;
            this.tbNOFpatients.Size = new System.Drawing.Size(289, 35);
            this.tbNOFpatients.TabIndex = 12;
            this.tbNOFpatients.TextChanged += new System.EventHandler(this.tbNOpatients_TextChanged);
            this.tbNOFpatients.Leave += new System.EventHandler(this.tbNOpatients_Leave);
            // 
            // tbfpBill
            // 
            this.tbfpBill.AutoRoundedCorners = true;
            this.tbfpBill.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbfpBill.BorderRadius = 16;
            this.tbfpBill.BorderThickness = 2;
            this.tbfpBill.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbfpBill.DefaultText = "";
            this.tbfpBill.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbfpBill.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbfpBill.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbfpBill.DisabledState.Parent = this.tbfpBill;
            this.tbfpBill.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbfpBill.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbfpBill.FocusedState.Parent = this.tbfpBill;
            this.tbfpBill.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbfpBill.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbfpBill.HoverState.Parent = this.tbfpBill;
            this.tbfpBill.Location = new System.Drawing.Point(151, 189);
            this.tbfpBill.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbfpBill.Name = "tbfpBill";
            this.tbfpBill.PasswordChar = '\0';
            this.tbfpBill.PlaceholderText = "";
            this.tbfpBill.SelectedText = "";
            this.tbfpBill.ShadowDecoration.Parent = this.tbfpBill;
            this.tbfpBill.Size = new System.Drawing.Size(289, 34);
            this.tbfpBill.TabIndex = 11;
            // 
            // cbWardName
            // 
            this.cbWardName.AutoRoundedCorners = true;
            this.cbWardName.BackColor = System.Drawing.Color.Transparent;
            this.cbWardName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbWardName.BorderRadius = 17;
            this.cbWardName.BorderThickness = 2;
            this.cbWardName.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbWardName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbWardName.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbWardName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbWardName.FocusedState.Parent = this.cbWardName;
            this.cbWardName.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbWardName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbWardName.HoverState.Parent = this.cbWardName;
            this.cbWardName.ItemHeight = 30;
            this.cbWardName.Items.AddRange(new object[] {
            "GOPD",
            "Antenetal",
            "Female Ward 1",
            "Female Ward 2",
            "Gynecology"});
            this.cbWardName.ItemsAppearance.Parent = this.cbWardName;
            this.cbWardName.Location = new System.Drawing.Point(151, 106);
            this.cbWardName.Name = "cbWardName";
            this.cbWardName.ShadowDecoration.Parent = this.cbWardName;
            this.cbWardName.Size = new System.Drawing.Size(289, 36);
            this.cbWardName.TabIndex = 10;
            // 
            // btnCancel
            // 
            this.btnCancel.AutoRoundedCorners = true;
            this.btnCancel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCancel.BorderRadius = 14;
            this.btnCancel.BorderThickness = 2;
            this.btnCancel.CheckedState.Parent = this.btnCancel;
            this.btnCancel.CustomImages.Parent = this.btnCancel;
            this.btnCancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnCancel.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.HoverState.Parent = this.btnCancel;
            this.btnCancel.Location = new System.Drawing.Point(299, 257);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.ShadowDecoration.Parent = this.btnCancel;
            this.btnCancel.Size = new System.Drawing.Size(99, 31);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.AutoRoundedCorners = true;
            this.btnSave.BackColor = System.Drawing.Color.Transparent;
            this.btnSave.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnSave.BorderRadius = 14;
            this.btnSave.BorderThickness = 2;
            this.btnSave.CheckedState.Parent = this.btnSave;
            this.btnSave.CustomImages.Parent = this.btnSave;
            this.btnSave.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnSave.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.HoverState.Parent = this.btnSave;
            this.btnSave.Location = new System.Drawing.Point(88, 257);
            this.btnSave.Name = "btnSave";
            this.btnSave.ShadowDecoration.Parent = this.btnSave;
            this.btnSave.Size = new System.Drawing.Size(103, 31);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmFemaleWard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 333);
            this.Controls.Add(this.guna2GroupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmFemaleWard";
            this.Text = "Female  Ward     General Hospital Management Solution";
            this.Load += new System.EventHandler(this.frmFemaleWard_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox tbNOFpatients;
        private Guna.UI2.WinForms.Guna2TextBox tbfpBill;
        private Guna.UI2.WinForms.Guna2ComboBox cbWardName;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2TextBox tbpatId;
        private Guna.UI2.WinForms.Guna2Button btnReadWard;
    }
}