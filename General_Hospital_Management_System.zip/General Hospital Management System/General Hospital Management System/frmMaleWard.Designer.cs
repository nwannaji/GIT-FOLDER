﻿namespace General_Hospital_Management_System
{
    partial class frmMaleWard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMaleWard));
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tbpatID = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnRead = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tbNOMpatients = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbmalePbill = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbWardName = new Guna.UI2.WinForms.Guna2ComboBox();
            this.btnCancel = new Guna.UI2.WinForms.Guna2Button();
            this.btnSave = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.AutoRoundedCorners = true;
            this.guna2GroupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2GroupBox1.BorderRadius = 131;
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel4);
            this.guna2GroupBox1.Controls.Add(this.tbpatID);
            this.guna2GroupBox1.Controls.Add(this.btnRead);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel3);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GroupBox1.Controls.Add(this.tbNOMpatients);
            this.guna2GroupBox1.Controls.Add(this.tbmalePbill);
            this.guna2GroupBox1.Controls.Add(this.cbWardName);
            this.guna2GroupBox1.Controls.Add(this.btnCancel);
            this.guna2GroupBox1.Controls.Add(this.btnSave);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(20, 18);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(488, 265);
            this.guna2GroupBox1.TabIndex = 1;
            this.guna2GroupBox1.Text = "                                                     Male  Ward";
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(90, 55);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(43, 21);
            this.guna2HtmlLabel4.TabIndex = 18;
            this.guna2HtmlLabel4.Text = "Pat Id";
            // 
            // tbpatID
            // 
            this.tbpatID.AutoRoundedCorners = true;
            this.tbpatID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbpatID.BorderRadius = 16;
            this.tbpatID.BorderThickness = 2;
            this.tbpatID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbpatID.DefaultText = "";
            this.tbpatID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbpatID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbpatID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbpatID.DisabledState.Parent = this.tbpatID;
            this.tbpatID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbpatID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbpatID.FocusedState.Parent = this.tbpatID;
            this.tbpatID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpatID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbpatID.HoverState.Parent = this.tbpatID;
            this.tbpatID.Location = new System.Drawing.Point(144, 49);
            this.tbpatID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbpatID.Name = "tbpatID";
            this.tbpatID.PasswordChar = '\0';
            this.tbpatID.PlaceholderText = "";
            this.tbpatID.SelectedText = "";
            this.tbpatID.ShadowDecoration.Parent = this.tbpatID;
            this.tbpatID.Size = new System.Drawing.Size(296, 35);
            this.tbpatID.TabIndex = 17;
            // 
            // btnRead
            // 
            this.btnRead.AutoRoundedCorners = true;
            this.btnRead.BackColor = System.Drawing.Color.Transparent;
            this.btnRead.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnRead.BorderRadius = 14;
            this.btnRead.BorderThickness = 2;
            this.btnRead.CheckedState.Parent = this.btnRead;
            this.btnRead.CustomImages.Parent = this.btnRead;
            this.btnRead.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnRead.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnRead.ForeColor = System.Drawing.Color.White;
            this.btnRead.HoverState.Parent = this.btnRead;
            this.btnRead.Location = new System.Drawing.Point(202, 220);
            this.btnRead.Name = "btnRead";
            this.btnRead.ShadowDecoration.Parent = this.btnRead;
            this.btnRead.Size = new System.Drawing.Size(92, 31);
            this.btnRead.TabIndex = 16;
            this.btnRead.Text = "Read";
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(62, 177);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel3.TabIndex = 15;
            this.guna2HtmlLabel3.Text = "Patient Bill";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(21, 136);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(119, 21);
            this.guna2HtmlLabel2.TabIndex = 14;
            this.guna2HtmlLabel2.Text = "Num Of Patients:";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(48, 96);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(89, 21);
            this.guna2HtmlLabel1.TabIndex = 13;
            this.guna2HtmlLabel1.Text = "Ward Name:";
            // 
            // tbNOMpatients
            // 
            this.tbNOMpatients.AutoRoundedCorners = true;
            this.tbNOMpatients.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbNOMpatients.BorderRadius = 16;
            this.tbNOMpatients.BorderThickness = 2;
            this.tbNOMpatients.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbNOMpatients.DefaultText = "";
            this.tbNOMpatients.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbNOMpatients.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbNOMpatients.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbNOMpatients.DisabledState.Parent = this.tbNOMpatients;
            this.tbNOMpatients.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbNOMpatients.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbNOMpatients.FocusedState.Parent = this.tbNOMpatients;
            this.tbNOMpatients.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNOMpatients.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbNOMpatients.HoverState.Parent = this.tbNOMpatients;
            this.tbNOMpatients.Location = new System.Drawing.Point(144, 133);
            this.tbNOMpatients.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbNOMpatients.Name = "tbNOMpatients";
            this.tbNOMpatients.PasswordChar = '\0';
            this.tbNOMpatients.PlaceholderText = "";
            this.tbNOMpatients.SelectedText = "";
            this.tbNOMpatients.ShadowDecoration.Parent = this.tbNOMpatients;
            this.tbNOMpatients.Size = new System.Drawing.Size(296, 35);
            this.tbNOMpatients.TabIndex = 12;
            this.tbNOMpatients.TextChanged += new System.EventHandler(this.tbNOMpatients_TextChanged);
            this.tbNOMpatients.Leave += new System.EventHandler(this.tbNOMpatients_Leave);
            // 
            // tbmalePbill
            // 
            this.tbmalePbill.AutoRoundedCorners = true;
            this.tbmalePbill.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbmalePbill.BorderRadius = 16;
            this.tbmalePbill.BorderThickness = 2;
            this.tbmalePbill.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbmalePbill.DefaultText = "";
            this.tbmalePbill.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbmalePbill.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbmalePbill.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbmalePbill.DisabledState.Parent = this.tbmalePbill;
            this.tbmalePbill.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbmalePbill.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbmalePbill.FocusedState.Parent = this.tbmalePbill;
            this.tbmalePbill.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbmalePbill.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbmalePbill.HoverState.Parent = this.tbmalePbill;
            this.tbmalePbill.Location = new System.Drawing.Point(144, 174);
            this.tbmalePbill.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbmalePbill.Name = "tbmalePbill";
            this.tbmalePbill.PasswordChar = '\0';
            this.tbmalePbill.PlaceholderText = "";
            this.tbmalePbill.SelectedText = "";
            this.tbmalePbill.ShadowDecoration.Parent = this.tbmalePbill;
            this.tbmalePbill.Size = new System.Drawing.Size(296, 34);
            this.tbmalePbill.TabIndex = 11;
            this.tbmalePbill.TextChanged += new System.EventHandler(this.tbmalePbill_TextChanged);
            this.tbmalePbill.Leave += new System.EventHandler(this.tbmalePbill_Leave);
            // 
            // cbWardName
            // 
            this.cbWardName.AutoRoundedCorners = true;
            this.cbWardName.BackColor = System.Drawing.Color.Transparent;
            this.cbWardName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbWardName.BorderRadius = 17;
            this.cbWardName.BorderThickness = 2;
            this.cbWardName.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbWardName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbWardName.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbWardName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbWardName.FocusedState.Parent = this.cbWardName;
            this.cbWardName.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbWardName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbWardName.HoverState.Parent = this.cbWardName;
            this.cbWardName.ItemHeight = 30;
            this.cbWardName.Items.AddRange(new object[] {
            "GOPD",
            "Male Ward 1",
            "Male Ward 2"});
            this.cbWardName.ItemsAppearance.Parent = this.cbWardName;
            this.cbWardName.Location = new System.Drawing.Point(140, 91);
            this.cbWardName.Name = "cbWardName";
            this.cbWardName.ShadowDecoration.Parent = this.cbWardName;
            this.cbWardName.Size = new System.Drawing.Size(300, 36);
            this.cbWardName.TabIndex = 10;
            // 
            // btnCancel
            // 
            this.btnCancel.AutoRoundedCorners = true;
            this.btnCancel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCancel.BorderRadius = 14;
            this.btnCancel.BorderThickness = 2;
            this.btnCancel.CheckedState.Parent = this.btnCancel;
            this.btnCancel.CustomImages.Parent = this.btnCancel;
            this.btnCancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnCancel.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.HoverState.Parent = this.btnCancel;
            this.btnCancel.Location = new System.Drawing.Point(326, 220);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.ShadowDecoration.Parent = this.btnCancel;
            this.btnCancel.Size = new System.Drawing.Size(74, 31);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.AutoRoundedCorners = true;
            this.btnSave.BackColor = System.Drawing.Color.Transparent;
            this.btnSave.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnSave.BorderRadius = 14;
            this.btnSave.BorderThickness = 2;
            this.btnSave.CheckedState.Parent = this.btnSave;
            this.btnSave.CustomImages.Parent = this.btnSave;
            this.btnSave.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnSave.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.HoverState.Parent = this.btnSave;
            this.btnSave.Location = new System.Drawing.Point(103, 220);
            this.btnSave.Name = "btnSave";
            this.btnSave.ShadowDecoration.Parent = this.btnSave;
            this.btnSave.Size = new System.Drawing.Size(81, 31);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmMaleWard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 290);
            this.Controls.Add(this.guna2GroupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMaleWard";
            this.Text = "Male Ward       General Hospital Management Solution";
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox tbNOMpatients;
        private Guna.UI2.WinForms.Guna2TextBox tbmalePbill;
        private Guna.UI2.WinForms.Guna2ComboBox cbWardName;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2TextBox tbpatID;
        private Guna.UI2.WinForms.Guna2Button btnRead;
    }
}