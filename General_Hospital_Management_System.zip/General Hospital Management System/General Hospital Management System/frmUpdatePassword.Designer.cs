﻿namespace General_Hospital_Management_System
{
    partial class frmUpdatePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUpdatePassword));
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.tbRepeatPass = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbNewPass = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbCurrentPass = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbUsername = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbEmpID = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnUpdatePass = new Guna.UI2.WinForms.Guna2Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.AutoRoundedCorners = true;
            this.guna2GroupBox1.BorderRadius = 145;
            this.guna2GroupBox1.Controls.Add(this.tbRepeatPass);
            this.guna2GroupBox1.Controls.Add(this.tbNewPass);
            this.guna2GroupBox1.Controls.Add(this.tbCurrentPass);
            this.guna2GroupBox1.Controls.Add(this.tbUsername);
            this.guna2GroupBox1.Controls.Add(this.tbEmpID);
            this.guna2GroupBox1.Controls.Add(this.btnUpdatePass);
            this.guna2GroupBox1.Controls.Add(this.label5);
            this.guna2GroupBox1.Controls.Add(this.label4);
            this.guna2GroupBox1.Controls.Add(this.label3);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(23, 12);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(497, 293);
            this.guna2GroupBox1.TabIndex = 0;
            this.guna2GroupBox1.Text = "                                                User Update";
            // 
            // tbRepeatPass
            // 
            this.tbRepeatPass.AutoRoundedCorners = true;
            this.tbRepeatPass.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbRepeatPass.BorderRadius = 15;
            this.tbRepeatPass.BorderThickness = 2;
            this.tbRepeatPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbRepeatPass.DefaultText = "";
            this.tbRepeatPass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbRepeatPass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbRepeatPass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbRepeatPass.DisabledState.Parent = this.tbRepeatPass;
            this.tbRepeatPass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbRepeatPass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbRepeatPass.FocusedState.Parent = this.tbRepeatPass;
            this.tbRepeatPass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRepeatPass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbRepeatPass.HoverState.Parent = this.tbRepeatPass;
            this.tbRepeatPass.Location = new System.Drawing.Point(161, 198);
            this.tbRepeatPass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbRepeatPass.Name = "tbRepeatPass";
            this.tbRepeatPass.PasswordChar = '*';
            this.tbRepeatPass.PlaceholderText = "";
            this.tbRepeatPass.SelectedText = "";
            this.tbRepeatPass.ShadowDecoration.Parent = this.tbRepeatPass;
            this.tbRepeatPass.Size = new System.Drawing.Size(214, 33);
            this.tbRepeatPass.TabIndex = 27;
            // 
            // tbNewPass
            // 
            this.tbNewPass.AutoRoundedCorners = true;
            this.tbNewPass.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbNewPass.BorderRadius = 15;
            this.tbNewPass.BorderThickness = 2;
            this.tbNewPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbNewPass.DefaultText = "";
            this.tbNewPass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbNewPass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbNewPass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbNewPass.DisabledState.Parent = this.tbNewPass;
            this.tbNewPass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbNewPass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbNewPass.FocusedState.Parent = this.tbNewPass;
            this.tbNewPass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNewPass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbNewPass.HoverState.Parent = this.tbNewPass;
            this.tbNewPass.Location = new System.Drawing.Point(161, 154);
            this.tbNewPass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbNewPass.Name = "tbNewPass";
            this.tbNewPass.PasswordChar = '*';
            this.tbNewPass.PlaceholderText = "";
            this.tbNewPass.SelectedText = "";
            this.tbNewPass.ShadowDecoration.Parent = this.tbNewPass;
            this.tbNewPass.Size = new System.Drawing.Size(214, 33);
            this.tbNewPass.TabIndex = 26;
            // 
            // tbCurrentPass
            // 
            this.tbCurrentPass.AutoRoundedCorners = true;
            this.tbCurrentPass.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbCurrentPass.BorderRadius = 15;
            this.tbCurrentPass.BorderThickness = 2;
            this.tbCurrentPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbCurrentPass.DefaultText = "";
            this.tbCurrentPass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbCurrentPass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbCurrentPass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbCurrentPass.DisabledState.Parent = this.tbCurrentPass;
            this.tbCurrentPass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbCurrentPass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbCurrentPass.FocusedState.Parent = this.tbCurrentPass;
            this.tbCurrentPass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCurrentPass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbCurrentPass.HoverState.Parent = this.tbCurrentPass;
            this.tbCurrentPass.Location = new System.Drawing.Point(161, 119);
            this.tbCurrentPass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbCurrentPass.Name = "tbCurrentPass";
            this.tbCurrentPass.PasswordChar = '*';
            this.tbCurrentPass.PlaceholderText = "";
            this.tbCurrentPass.SelectedText = "";
            this.tbCurrentPass.ShadowDecoration.Parent = this.tbCurrentPass;
            this.tbCurrentPass.Size = new System.Drawing.Size(214, 33);
            this.tbCurrentPass.TabIndex = 25;
            // 
            // tbUsername
            // 
            this.tbUsername.AutoRoundedCorners = true;
            this.tbUsername.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbUsername.BorderRadius = 15;
            this.tbUsername.BorderThickness = 2;
            this.tbUsername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbUsername.DefaultText = "";
            this.tbUsername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbUsername.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbUsername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUsername.DisabledState.Parent = this.tbUsername;
            this.tbUsername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUsername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUsername.FocusedState.Parent = this.tbUsername;
            this.tbUsername.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbUsername.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUsername.HoverState.Parent = this.tbUsername;
            this.tbUsername.Location = new System.Drawing.Point(161, 84);
            this.tbUsername.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.PasswordChar = '\0';
            this.tbUsername.PlaceholderText = "";
            this.tbUsername.SelectedText = "";
            this.tbUsername.ShadowDecoration.Parent = this.tbUsername;
            this.tbUsername.Size = new System.Drawing.Size(214, 33);
            this.tbUsername.TabIndex = 24;
            // 
            // tbEmpID
            // 
            this.tbEmpID.AutoRoundedCorners = true;
            this.tbEmpID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbEmpID.BorderRadius = 15;
            this.tbEmpID.BorderThickness = 2;
            this.tbEmpID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbEmpID.DefaultText = "";
            this.tbEmpID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbEmpID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbEmpID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbEmpID.DisabledState.Parent = this.tbEmpID;
            this.tbEmpID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbEmpID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbEmpID.FocusedState.Parent = this.tbEmpID;
            this.tbEmpID.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbEmpID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbEmpID.HoverState.Parent = this.tbEmpID;
            this.tbEmpID.Location = new System.Drawing.Point(161, 49);
            this.tbEmpID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbEmpID.Name = "tbEmpID";
            this.tbEmpID.PasswordChar = '\0';
            this.tbEmpID.PlaceholderText = "";
            this.tbEmpID.SelectedText = "";
            this.tbEmpID.ShadowDecoration.Parent = this.tbEmpID;
            this.tbEmpID.Size = new System.Drawing.Size(214, 33);
            this.tbEmpID.TabIndex = 23;
            // 
            // btnUpdatePass
            // 
            this.btnUpdatePass.AutoRoundedCorners = true;
            this.btnUpdatePass.BackColor = System.Drawing.Color.White;
            this.btnUpdatePass.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnUpdatePass.BorderRadius = 15;
            this.btnUpdatePass.BorderThickness = 2;
            this.btnUpdatePass.CheckedState.Parent = this.btnUpdatePass;
            this.btnUpdatePass.CustomImages.Parent = this.btnUpdatePass;
            this.btnUpdatePass.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnUpdatePass.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnUpdatePass.ForeColor = System.Drawing.Color.White;
            this.btnUpdatePass.HoverState.Parent = this.btnUpdatePass;
            this.btnUpdatePass.Location = new System.Drawing.Point(174, 247);
            this.btnUpdatePass.Name = "btnUpdatePass";
            this.btnUpdatePass.ShadowDecoration.Parent = this.btnUpdatePass;
            this.btnUpdatePass.Size = new System.Drawing.Size(180, 33);
            this.btnUpdatePass.TabIndex = 22;
            this.btnUpdatePass.Text = "Update Password";
            this.btnUpdatePass.Click += new System.EventHandler(this.btnUpdatePass_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 17);
            this.label5.TabIndex = 21;
            this.label5.Text = "Repeat New Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(53, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 19);
            this.label4.TabIndex = 20;
            this.label4.Text = "New Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 19);
            this.label3.TabIndex = 19;
            this.label3.Text = "Current Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(84, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 19);
            this.label2.TabIndex = 18;
            this.label2.Text = "Username";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(69, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 19);
            this.label1.TabIndex = 17;
            this.label1.Text = "EmployeeID";
            // 
            // frmUpdatePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(539, 315);
            this.Controls.Add(this.guna2GroupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmUpdatePassword";
            this.Text = "Update  Password";
            this.Load += new System.EventHandler(this.frmUpdatePassword_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2TextBox tbRepeatPass;
        private Guna.UI2.WinForms.Guna2TextBox tbNewPass;
        private Guna.UI2.WinForms.Guna2TextBox tbCurrentPass;
        private Guna.UI2.WinForms.Guna2TextBox tbUsername;
        private Guna.UI2.WinForms.Guna2TextBox tbEmpID;
        private Guna.UI2.WinForms.Guna2Button btnUpdatePass;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}