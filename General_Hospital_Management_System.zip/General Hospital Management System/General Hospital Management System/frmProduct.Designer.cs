﻿namespace General_Hospital_Management_System
{
    partial class frmProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProduct));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnAddStock = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.dtpExpiryDate = new System.Windows.Forms.DateTimePicker();
            this.dtpManufactureDate = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tbItemLocation = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbItemDetails = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbItemQuantity = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbItemPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbItemName = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbSuppliedBy = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.dtpUpExpiryDate = new System.Windows.Forms.DateTimePicker();
            this.dtpUpManDate = new System.Windows.Forms.DateTimePicker();
            this.btnRemoveItem = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.btnUpdateItem = new Guna.UI2.WinForms.Guna2Button();
            this.lebel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.Label = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.gunaLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.ItemLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tbUpdateProLocation = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbUpdateSuppliedBy = new Guna.UI2.WinForms.Guna2ComboBox();
            this.tbUpdateProDetails = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbUpdateProQ = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbUpdateProPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbUpdateProName = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbUpdateProID = new Guna.UI2.WinForms.Guna2TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.getQty = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnItem_Sold = new Guna.UI2.WinForms.Guna2Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tbTotal = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbQuantity = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbPatName = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbPatID = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbLoadDrugsName = new Guna.UI2.WinForms.Guna2ComboBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.guna2GroupBox4 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tb_PatID = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lblTotal = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.btnCheckout = new Guna.UI2.WinForms.Guna2Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.btnClose = new Guna.UI2.WinForms.Guna2Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.guna2GroupBox2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.guna2GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.guna2GroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(27, 23);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(739, 615);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tabPage1.Controls.Add(this.btnAddStock);
            this.tabPage1.Controls.Add(this.guna2GroupBox1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(731, 587);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Add New Stock";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // btnAddStock
            // 
            this.btnAddStock.AutoRoundedCorners = true;
            this.btnAddStock.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnAddStock.BorderRadius = 12;
            this.btnAddStock.BorderThickness = 1;
            this.btnAddStock.CheckedState.Parent = this.btnAddStock;
            this.btnAddStock.CustomImages.Parent = this.btnAddStock;
            this.btnAddStock.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnAddStock.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnAddStock.ForeColor = System.Drawing.Color.White;
            this.btnAddStock.HoverState.Parent = this.btnAddStock;
            this.btnAddStock.Location = new System.Drawing.Point(521, 531);
            this.btnAddStock.Name = "btnAddStock";
            this.btnAddStock.ShadowDecoration.Parent = this.btnAddStock;
            this.btnAddStock.Size = new System.Drawing.Size(180, 45);
            this.btnAddStock.TabIndex = 8;
            this.btnAddStock.Text = "Add Stock";
            this.btnAddStock.Click += new System.EventHandler(this.btnAddStock_Click);
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.AutoRoundedCorners = true;
            this.guna2GroupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.guna2GroupBox1.BorderRadius = 220;
            this.guna2GroupBox1.Controls.Add(this.dtpExpiryDate);
            this.guna2GroupBox1.Controls.Add(this.dtpManufactureDate);
            this.guna2GroupBox1.Controls.Add(this.label8);
            this.guna2GroupBox1.Controls.Add(this.label7);
            this.guna2GroupBox1.Controls.Add(this.label6);
            this.guna2GroupBox1.Controls.Add(this.label5);
            this.guna2GroupBox1.Controls.Add(this.label4);
            this.guna2GroupBox1.Controls.Add(this.label3);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GroupBox1.Controls.Add(this.tbItemLocation);
            this.guna2GroupBox1.Controls.Add(this.tbItemDetails);
            this.guna2GroupBox1.Controls.Add(this.tbItemQuantity);
            this.guna2GroupBox1.Controls.Add(this.tbItemPrice);
            this.guna2GroupBox1.Controls.Add(this.tbItemName);
            this.guna2GroupBox1.Controls.Add(this.cbSuppliedBy);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(60, 82);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(641, 443);
            this.guna2GroupBox1.TabIndex = 1;
            this.guna2GroupBox1.Text = "                                                   Add New Item";
            // 
            // dtpExpiryDate
            // 
            this.dtpExpiryDate.Location = new System.Drawing.Point(167, 344);
            this.dtpExpiryDate.Name = "dtpExpiryDate";
            this.dtpExpiryDate.Size = new System.Drawing.Size(226, 26);
            this.dtpExpiryDate.TabIndex = 17;
            // 
            // dtpManufactureDate
            // 
            this.dtpManufactureDate.Location = new System.Drawing.Point(167, 270);
            this.dtpManufactureDate.Name = "dtpManufactureDate";
            this.dtpManufactureDate.Size = new System.Drawing.Size(226, 26);
            this.dtpManufactureDate.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(64, 349);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 19);
            this.label8.TabIndex = 15;
            this.label8.Text = "Expiry Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(46, 310);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 19);
            this.label7.TabIndex = 14;
            this.label7.Text = "Item Location";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(23, 270);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 19);
            this.label6.TabIndex = 13;
            this.label6.Text = "Manufacture Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(64, 235);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 19);
            this.label5.TabIndex = 12;
            this.label5.Text = "Item Details";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(51, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 19);
            this.label4.TabIndex = 11;
            this.label4.Text = "Item Quantity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(77, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 19);
            this.label3.TabIndex = 10;
            this.label3.Text = "Item Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(65, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 19);
            this.label2.TabIndex = 9;
            this.label2.Text = "Supplied By";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(77, 64);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(71, 21);
            this.guna2HtmlLabel1.TabIndex = 8;
            this.guna2HtmlLabel1.Text = "Item Name";
            // 
            // tbItemLocation
            // 
            this.tbItemLocation.AutoRoundedCorners = true;
            this.tbItemLocation.BorderRadius = 18;
            this.tbItemLocation.BorderThickness = 2;
            this.tbItemLocation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbItemLocation.DefaultText = "";
            this.tbItemLocation.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbItemLocation.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbItemLocation.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemLocation.DisabledState.Parent = this.tbItemLocation;
            this.tbItemLocation.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemLocation.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemLocation.FocusedState.Parent = this.tbItemLocation;
            this.tbItemLocation.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbItemLocation.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemLocation.HoverState.Parent = this.tbItemLocation;
            this.tbItemLocation.Location = new System.Drawing.Point(167, 302);
            this.tbItemLocation.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbItemLocation.Name = "tbItemLocation";
            this.tbItemLocation.PasswordChar = '\0';
            this.tbItemLocation.PlaceholderText = "";
            this.tbItemLocation.SelectedText = "";
            this.tbItemLocation.ShadowDecoration.Parent = this.tbItemLocation;
            this.tbItemLocation.Size = new System.Drawing.Size(226, 38);
            this.tbItemLocation.TabIndex = 6;
            this.tbItemLocation.TextChanged += new System.EventHandler(this.tbItemLocation_TextChanged_1);
            this.tbItemLocation.Leave += new System.EventHandler(this.tbItemLocation_Leave);
            // 
            // tbItemDetails
            // 
            this.tbItemDetails.AutoRoundedCorners = true;
            this.tbItemDetails.BorderRadius = 17;
            this.tbItemDetails.BorderThickness = 2;
            this.tbItemDetails.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbItemDetails.DefaultText = "";
            this.tbItemDetails.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbItemDetails.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbItemDetails.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemDetails.DisabledState.Parent = this.tbItemDetails;
            this.tbItemDetails.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemDetails.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemDetails.FocusedState.Parent = this.tbItemDetails;
            this.tbItemDetails.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbItemDetails.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemDetails.HoverState.Parent = this.tbItemDetails;
            this.tbItemDetails.Location = new System.Drawing.Point(167, 229);
            this.tbItemDetails.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbItemDetails.Name = "tbItemDetails";
            this.tbItemDetails.PasswordChar = '\0';
            this.tbItemDetails.PlaceholderText = "";
            this.tbItemDetails.SelectedText = "";
            this.tbItemDetails.ShadowDecoration.Parent = this.tbItemDetails;
            this.tbItemDetails.Size = new System.Drawing.Size(226, 36);
            this.tbItemDetails.TabIndex = 4;
            this.tbItemDetails.TextChanged += new System.EventHandler(this.tbItemDetails_TextChanged);
            this.tbItemDetails.Leave += new System.EventHandler(this.tbItemDetails_Leave);
            // 
            // tbItemQuantity
            // 
            this.tbItemQuantity.AutoRoundedCorners = true;
            this.tbItemQuantity.BorderRadius = 17;
            this.tbItemQuantity.BorderThickness = 2;
            this.tbItemQuantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbItemQuantity.DefaultText = "";
            this.tbItemQuantity.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbItemQuantity.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbItemQuantity.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemQuantity.DisabledState.Parent = this.tbItemQuantity;
            this.tbItemQuantity.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemQuantity.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemQuantity.FocusedState.Parent = this.tbItemQuantity;
            this.tbItemQuantity.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbItemQuantity.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemQuantity.HoverState.Parent = this.tbItemQuantity;
            this.tbItemQuantity.Location = new System.Drawing.Point(167, 186);
            this.tbItemQuantity.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbItemQuantity.Name = "tbItemQuantity";
            this.tbItemQuantity.PasswordChar = '\0';
            this.tbItemQuantity.PlaceholderText = "";
            this.tbItemQuantity.SelectedText = "";
            this.tbItemQuantity.ShadowDecoration.Parent = this.tbItemQuantity;
            this.tbItemQuantity.Size = new System.Drawing.Size(226, 36);
            this.tbItemQuantity.TabIndex = 3;
            this.tbItemQuantity.TextChanged += new System.EventHandler(this.tbItemQuantity_TextChanged);
            this.tbItemQuantity.Leave += new System.EventHandler(this.tbItemQuantity_Leave);
            // 
            // tbItemPrice
            // 
            this.tbItemPrice.AutoRoundedCorners = true;
            this.tbItemPrice.BorderRadius = 17;
            this.tbItemPrice.BorderThickness = 2;
            this.tbItemPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbItemPrice.DefaultText = "";
            this.tbItemPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbItemPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbItemPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemPrice.DisabledState.Parent = this.tbItemPrice;
            this.tbItemPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemPrice.FocusedState.Parent = this.tbItemPrice;
            this.tbItemPrice.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbItemPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemPrice.HoverState.Parent = this.tbItemPrice;
            this.tbItemPrice.Location = new System.Drawing.Point(167, 143);
            this.tbItemPrice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbItemPrice.Name = "tbItemPrice";
            this.tbItemPrice.PasswordChar = '\0';
            this.tbItemPrice.PlaceholderText = "";
            this.tbItemPrice.SelectedText = "";
            this.tbItemPrice.ShadowDecoration.Parent = this.tbItemPrice;
            this.tbItemPrice.Size = new System.Drawing.Size(226, 36);
            this.tbItemPrice.TabIndex = 2;
            this.tbItemPrice.TextChanged += new System.EventHandler(this.tbItemPrice_TextChanged);
            this.tbItemPrice.Leave += new System.EventHandler(this.tbItemPrice_Leave);
            // 
            // tbItemName
            // 
            this.tbItemName.AutoRoundedCorners = true;
            this.tbItemName.BorderRadius = 17;
            this.tbItemName.BorderThickness = 2;
            this.tbItemName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbItemName.DefaultText = "";
            this.tbItemName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbItemName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbItemName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemName.DisabledState.Parent = this.tbItemName;
            this.tbItemName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbItemName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemName.FocusedState.Parent = this.tbItemName;
            this.tbItemName.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbItemName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbItemName.HoverState.Parent = this.tbItemName;
            this.tbItemName.Location = new System.Drawing.Point(167, 60);
            this.tbItemName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbItemName.Name = "tbItemName";
            this.tbItemName.PasswordChar = '\0';
            this.tbItemName.PlaceholderText = "";
            this.tbItemName.SelectedText = "";
            this.tbItemName.ShadowDecoration.Parent = this.tbItemName;
            this.tbItemName.Size = new System.Drawing.Size(226, 36);
            this.tbItemName.TabIndex = 1;
            this.tbItemName.TextChanged += new System.EventHandler(this.tbItemName_TextChanged);
            this.tbItemName.Leave += new System.EventHandler(this.tbItemName_Leave);
            // 
            // cbSuppliedBy
            // 
            this.cbSuppliedBy.AutoRoundedCorners = true;
            this.cbSuppliedBy.BackColor = System.Drawing.Color.Transparent;
            this.cbSuppliedBy.BorderRadius = 17;
            this.cbSuppliedBy.BorderThickness = 2;
            this.cbSuppliedBy.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbSuppliedBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSuppliedBy.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbSuppliedBy.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbSuppliedBy.FocusedState.Parent = this.cbSuppliedBy;
            this.cbSuppliedBy.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbSuppliedBy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbSuppliedBy.HoverState.Parent = this.cbSuppliedBy;
            this.cbSuppliedBy.ItemHeight = 30;
            this.cbSuppliedBy.ItemsAppearance.Parent = this.cbSuppliedBy;
            this.cbSuppliedBy.Location = new System.Drawing.Point(167, 101);
            this.cbSuppliedBy.Name = "cbSuppliedBy";
            this.cbSuppliedBy.ShadowDecoration.Parent = this.cbSuppliedBy;
            this.cbSuppliedBy.Size = new System.Drawing.Size(226, 36);
            this.cbSuppliedBy.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(267, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add New Stock";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.guna2GroupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(731, 587);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Update Sock";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.AutoRoundedCorners = true;
            this.guna2GroupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.guna2GroupBox2.BorderRadius = 274;
            this.guna2GroupBox2.Controls.Add(this.dtpUpExpiryDate);
            this.guna2GroupBox2.Controls.Add(this.dtpUpManDate);
            this.guna2GroupBox2.Controls.Add(this.btnRemoveItem);
            this.guna2GroupBox2.Controls.Add(this.guna2HtmlLabel10);
            this.guna2GroupBox2.Controls.Add(this.btnUpdateItem);
            this.guna2GroupBox2.Controls.Add(this.lebel);
            this.guna2GroupBox2.Controls.Add(this.Label);
            this.guna2GroupBox2.Controls.Add(this.gunaLabel);
            this.guna2GroupBox2.Controls.Add(this.ItemLabel);
            this.guna2GroupBox2.Controls.Add(this.guna2HtmlLabel5);
            this.guna2GroupBox2.Controls.Add(this.guna2HtmlLabel4);
            this.guna2GroupBox2.Controls.Add(this.guna2HtmlLabel3);
            this.guna2GroupBox2.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GroupBox2.Controls.Add(this.tbUpdateProLocation);
            this.guna2GroupBox2.Controls.Add(this.cbUpdateSuppliedBy);
            this.guna2GroupBox2.Controls.Add(this.tbUpdateProDetails);
            this.guna2GroupBox2.Controls.Add(this.tbUpdateProQ);
            this.guna2GroupBox2.Controls.Add(this.tbUpdateProPrice);
            this.guna2GroupBox2.Controls.Add(this.tbUpdateProName);
            this.guna2GroupBox2.Controls.Add(this.tbUpdateProID);
            this.guna2GroupBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox2.Location = new System.Drawing.Point(43, 43);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.ShadowDecoration.Parent = this.guna2GroupBox2;
            this.guna2GroupBox2.Size = new System.Drawing.Size(643, 550);
            this.guna2GroupBox2.TabIndex = 1;
            this.guna2GroupBox2.Text = "                                                             Update Item";
            this.guna2GroupBox2.Click += new System.EventHandler(this.guna2GroupBox2_Click);
            // 
            // dtpUpExpiryDate
            // 
            this.dtpUpExpiryDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpUpExpiryDate.Location = new System.Drawing.Point(193, 405);
            this.dtpUpExpiryDate.Name = "dtpUpExpiryDate";
            this.dtpUpExpiryDate.Size = new System.Drawing.Size(238, 26);
            this.dtpUpExpiryDate.TabIndex = 19;
            // 
            // dtpUpManDate
            // 
            this.dtpUpManDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpUpManDate.Location = new System.Drawing.Point(193, 329);
            this.dtpUpManDate.Name = "dtpUpManDate";
            this.dtpUpManDate.Size = new System.Drawing.Size(238, 26);
            this.dtpUpManDate.TabIndex = 18;
            // 
            // btnRemoveItem
            // 
            this.btnRemoveItem.AutoRoundedCorners = true;
            this.btnRemoveItem.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnRemoveItem.BorderRadius = 13;
            this.btnRemoveItem.BorderThickness = 2;
            this.btnRemoveItem.CheckedState.Parent = this.btnRemoveItem;
            this.btnRemoveItem.CustomImages.Parent = this.btnRemoveItem;
            this.btnRemoveItem.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnRemoveItem.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnRemoveItem.ForeColor = System.Drawing.Color.White;
            this.btnRemoveItem.HoverState.Parent = this.btnRemoveItem;
            this.btnRemoveItem.Location = new System.Drawing.Point(525, 502);
            this.btnRemoveItem.Name = "btnRemoveItem";
            this.btnRemoveItem.ShadowDecoration.Parent = this.btnRemoveItem;
            this.btnRemoveItem.Size = new System.Drawing.Size(109, 29);
            this.btnRemoveItem.TabIndex = 3;
            this.btnRemoveItem.Text = "Remove Item";
            this.btnRemoveItem.Click += new System.EventHandler(this.btnRemoveItem_Click);
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(103, 410);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(75, 21);
            this.guna2HtmlLabel10.TabIndex = 17;
            this.guna2HtmlLabel10.Text = "Expiry Date";
            // 
            // btnUpdateItem
            // 
            this.btnUpdateItem.AutoRoundedCorners = true;
            this.btnUpdateItem.BorderColor = System.Drawing.Color.White;
            this.btnUpdateItem.BorderRadius = 15;
            this.btnUpdateItem.BorderThickness = 2;
            this.btnUpdateItem.CheckedState.Parent = this.btnUpdateItem;
            this.btnUpdateItem.CustomImages.Parent = this.btnUpdateItem;
            this.btnUpdateItem.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnUpdateItem.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnUpdateItem.ForeColor = System.Drawing.Color.White;
            this.btnUpdateItem.HoverState.Parent = this.btnUpdateItem;
            this.btnUpdateItem.Location = new System.Drawing.Point(6, 502);
            this.btnUpdateItem.Name = "btnUpdateItem";
            this.btnUpdateItem.ShadowDecoration.Parent = this.btnUpdateItem;
            this.btnUpdateItem.Size = new System.Drawing.Size(108, 33);
            this.btnUpdateItem.TabIndex = 2;
            this.btnUpdateItem.Text = "Update Item";
            this.btnUpdateItem.Click += new System.EventHandler(this.btnUpdateItem_Click);
            // 
            // lebel
            // 
            this.lebel.BackColor = System.Drawing.Color.Transparent;
            this.lebel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lebel.Location = new System.Drawing.Point(90, 369);
            this.lebel.Name = "lebel";
            this.lebel.Size = new System.Drawing.Size(87, 21);
            this.lebel.TabIndex = 16;
            this.lebel.Text = "Item Location";
            // 
            // Label
            // 
            this.Label.BackColor = System.Drawing.Color.Transparent;
            this.Label.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label.Location = new System.Drawing.Point(60, 329);
            this.Label.Name = "Label";
            this.Label.Size = new System.Drawing.Size(112, 21);
            this.Label.TabIndex = 15;
            this.Label.Text = "Manufacture Date";
            // 
            // gunaLabel
            // 
            this.gunaLabel.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel.Location = new System.Drawing.Point(90, 294);
            this.gunaLabel.Name = "gunaLabel";
            this.gunaLabel.Size = new System.Drawing.Size(75, 21);
            this.gunaLabel.TabIndex = 14;
            this.gunaLabel.Text = "Item Details";
            // 
            // ItemLabel
            // 
            this.ItemLabel.BackColor = System.Drawing.Color.Transparent;
            this.ItemLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemLabel.Location = new System.Drawing.Point(90, 251);
            this.ItemLabel.Name = "ItemLabel";
            this.ItemLabel.Size = new System.Drawing.Size(85, 21);
            this.ItemLabel.TabIndex = 13;
            this.ItemLabel.Text = "Item Quantity";
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(104, 209);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(65, 21);
            this.guna2HtmlLabel5.TabIndex = 12;
            this.guna2HtmlLabel5.Text = "Item Price";
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(103, 164);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(73, 21);
            this.guna2HtmlLabel4.TabIndex = 11;
            this.guna2HtmlLabel4.Text = "SuppliedBy";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(103, 120);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(71, 21);
            this.guna2HtmlLabel3.TabIndex = 10;
            this.guna2HtmlLabel3.Text = "Item Name";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(94, 77);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(84, 21);
            this.guna2HtmlLabel2.TabIndex = 9;
            this.guna2HtmlLabel2.Text = "Item Number";
            // 
            // tbUpdateProLocation
            // 
            this.tbUpdateProLocation.AutoRoundedCorners = true;
            this.tbUpdateProLocation.BorderRadius = 17;
            this.tbUpdateProLocation.BorderThickness = 2;
            this.tbUpdateProLocation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbUpdateProLocation.DefaultText = "";
            this.tbUpdateProLocation.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbUpdateProLocation.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbUpdateProLocation.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProLocation.DisabledState.Parent = this.tbUpdateProLocation;
            this.tbUpdateProLocation.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProLocation.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProLocation.FocusedState.Parent = this.tbUpdateProLocation;
            this.tbUpdateProLocation.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbUpdateProLocation.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProLocation.HoverState.Parent = this.tbUpdateProLocation;
            this.tbUpdateProLocation.Location = new System.Drawing.Point(193, 362);
            this.tbUpdateProLocation.Margin = new System.Windows.Forms.Padding(4);
            this.tbUpdateProLocation.Name = "tbUpdateProLocation";
            this.tbUpdateProLocation.PasswordChar = '\0';
            this.tbUpdateProLocation.PlaceholderText = "";
            this.tbUpdateProLocation.SelectedText = "";
            this.tbUpdateProLocation.ShadowDecoration.Parent = this.tbUpdateProLocation;
            this.tbUpdateProLocation.Size = new System.Drawing.Size(238, 36);
            this.tbUpdateProLocation.TabIndex = 7;
            // 
            // cbUpdateSuppliedBy
            // 
            this.cbUpdateSuppliedBy.AutoRoundedCorners = true;
            this.cbUpdateSuppliedBy.BackColor = System.Drawing.Color.Transparent;
            this.cbUpdateSuppliedBy.BorderRadius = 17;
            this.cbUpdateSuppliedBy.BorderThickness = 2;
            this.cbUpdateSuppliedBy.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbUpdateSuppliedBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbUpdateSuppliedBy.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbUpdateSuppliedBy.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbUpdateSuppliedBy.FocusedState.Parent = this.cbUpdateSuppliedBy;
            this.cbUpdateSuppliedBy.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbUpdateSuppliedBy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbUpdateSuppliedBy.HoverState.Parent = this.cbUpdateSuppliedBy;
            this.cbUpdateSuppliedBy.ItemHeight = 30;
            this.cbUpdateSuppliedBy.ItemsAppearance.Parent = this.cbUpdateSuppliedBy;
            this.cbUpdateSuppliedBy.Location = new System.Drawing.Point(193, 159);
            this.cbUpdateSuppliedBy.Name = "cbUpdateSuppliedBy";
            this.cbUpdateSuppliedBy.ShadowDecoration.Parent = this.cbUpdateSuppliedBy;
            this.cbUpdateSuppliedBy.Size = new System.Drawing.Size(238, 36);
            this.cbUpdateSuppliedBy.TabIndex = 6;
            // 
            // tbUpdateProDetails
            // 
            this.tbUpdateProDetails.AutoRoundedCorners = true;
            this.tbUpdateProDetails.BorderRadius = 17;
            this.tbUpdateProDetails.BorderThickness = 2;
            this.tbUpdateProDetails.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbUpdateProDetails.DefaultText = "";
            this.tbUpdateProDetails.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbUpdateProDetails.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbUpdateProDetails.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProDetails.DisabledState.Parent = this.tbUpdateProDetails;
            this.tbUpdateProDetails.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProDetails.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProDetails.FocusedState.Parent = this.tbUpdateProDetails;
            this.tbUpdateProDetails.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbUpdateProDetails.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProDetails.HoverState.Parent = this.tbUpdateProDetails;
            this.tbUpdateProDetails.Location = new System.Drawing.Point(193, 289);
            this.tbUpdateProDetails.Margin = new System.Windows.Forms.Padding(4);
            this.tbUpdateProDetails.Name = "tbUpdateProDetails";
            this.tbUpdateProDetails.PasswordChar = '\0';
            this.tbUpdateProDetails.PlaceholderText = "";
            this.tbUpdateProDetails.SelectedText = "";
            this.tbUpdateProDetails.ShadowDecoration.Parent = this.tbUpdateProDetails;
            this.tbUpdateProDetails.Size = new System.Drawing.Size(238, 36);
            this.tbUpdateProDetails.TabIndex = 4;
            // 
            // tbUpdateProQ
            // 
            this.tbUpdateProQ.AutoRoundedCorners = true;
            this.tbUpdateProQ.BorderRadius = 17;
            this.tbUpdateProQ.BorderThickness = 2;
            this.tbUpdateProQ.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbUpdateProQ.DefaultText = "";
            this.tbUpdateProQ.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbUpdateProQ.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbUpdateProQ.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProQ.DisabledState.Parent = this.tbUpdateProQ;
            this.tbUpdateProQ.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProQ.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProQ.FocusedState.Parent = this.tbUpdateProQ;
            this.tbUpdateProQ.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbUpdateProQ.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProQ.HoverState.Parent = this.tbUpdateProQ;
            this.tbUpdateProQ.Location = new System.Drawing.Point(194, 245);
            this.tbUpdateProQ.Margin = new System.Windows.Forms.Padding(4);
            this.tbUpdateProQ.Name = "tbUpdateProQ";
            this.tbUpdateProQ.PasswordChar = '\0';
            this.tbUpdateProQ.PlaceholderText = "";
            this.tbUpdateProQ.SelectedText = "";
            this.tbUpdateProQ.ShadowDecoration.Parent = this.tbUpdateProQ;
            this.tbUpdateProQ.Size = new System.Drawing.Size(237, 36);
            this.tbUpdateProQ.TabIndex = 3;
            this.tbUpdateProQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUpdateProQ_KeyPress);
            // 
            // tbUpdateProPrice
            // 
            this.tbUpdateProPrice.AutoRoundedCorners = true;
            this.tbUpdateProPrice.BorderRadius = 17;
            this.tbUpdateProPrice.BorderThickness = 2;
            this.tbUpdateProPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbUpdateProPrice.DefaultText = "";
            this.tbUpdateProPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbUpdateProPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbUpdateProPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProPrice.DisabledState.Parent = this.tbUpdateProPrice;
            this.tbUpdateProPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProPrice.FocusedState.Parent = this.tbUpdateProPrice;
            this.tbUpdateProPrice.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbUpdateProPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProPrice.HoverState.Parent = this.tbUpdateProPrice;
            this.tbUpdateProPrice.Location = new System.Drawing.Point(193, 201);
            this.tbUpdateProPrice.Margin = new System.Windows.Forms.Padding(4);
            this.tbUpdateProPrice.Name = "tbUpdateProPrice";
            this.tbUpdateProPrice.PasswordChar = '\0';
            this.tbUpdateProPrice.PlaceholderText = "";
            this.tbUpdateProPrice.SelectedText = "";
            this.tbUpdateProPrice.ShadowDecoration.Parent = this.tbUpdateProPrice;
            this.tbUpdateProPrice.Size = new System.Drawing.Size(238, 36);
            this.tbUpdateProPrice.TabIndex = 2;
            this.tbUpdateProPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUpdateProPrice_KeyPress);
            // 
            // tbUpdateProName
            // 
            this.tbUpdateProName.AutoRoundedCorners = true;
            this.tbUpdateProName.BorderRadius = 17;
            this.tbUpdateProName.BorderThickness = 2;
            this.tbUpdateProName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbUpdateProName.DefaultText = "";
            this.tbUpdateProName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbUpdateProName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbUpdateProName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProName.DisabledState.Parent = this.tbUpdateProName;
            this.tbUpdateProName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProName.FocusedState.Parent = this.tbUpdateProName;
            this.tbUpdateProName.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbUpdateProName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProName.HoverState.Parent = this.tbUpdateProName;
            this.tbUpdateProName.Location = new System.Drawing.Point(193, 115);
            this.tbUpdateProName.Margin = new System.Windows.Forms.Padding(4);
            this.tbUpdateProName.Name = "tbUpdateProName";
            this.tbUpdateProName.PasswordChar = '\0';
            this.tbUpdateProName.PlaceholderText = "";
            this.tbUpdateProName.SelectedText = "";
            this.tbUpdateProName.ShadowDecoration.Parent = this.tbUpdateProName;
            this.tbUpdateProName.Size = new System.Drawing.Size(238, 36);
            this.tbUpdateProName.TabIndex = 1;
            // 
            // tbUpdateProID
            // 
            this.tbUpdateProID.AutoRoundedCorners = true;
            this.tbUpdateProID.BorderRadius = 17;
            this.tbUpdateProID.BorderThickness = 2;
            this.tbUpdateProID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbUpdateProID.DefaultText = "";
            this.tbUpdateProID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbUpdateProID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbUpdateProID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProID.DisabledState.Parent = this.tbUpdateProID;
            this.tbUpdateProID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbUpdateProID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProID.FocusedState.Parent = this.tbUpdateProID;
            this.tbUpdateProID.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.tbUpdateProID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbUpdateProID.HoverState.Parent = this.tbUpdateProID;
            this.tbUpdateProID.Location = new System.Drawing.Point(193, 71);
            this.tbUpdateProID.Margin = new System.Windows.Forms.Padding(4);
            this.tbUpdateProID.Name = "tbUpdateProID";
            this.tbUpdateProID.PasswordChar = '\0';
            this.tbUpdateProID.PlaceholderText = "";
            this.tbUpdateProID.SelectedText = "";
            this.tbUpdateProID.ShadowDecoration.Parent = this.tbUpdateProID;
            this.tbUpdateProID.Size = new System.Drawing.Size(238, 36);
            this.tbUpdateProID.TabIndex = 0;
            this.tbUpdateProID.TextChanged += new System.EventHandler(this.tbUpdateProID_TextChanged);
            this.tbUpdateProID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUpdateProID_KeyPress);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.guna2Button1);
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(731, 587);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "View Stock";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BorderRadius = 21;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(486, 527);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(180, 45);
            this.guna2Button1.TabIndex = 1;
            this.guna2Button1.Text = "Refresh";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(36, 93);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(675, 385);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.guna2GroupBox3);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(731, 587);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Sell Items";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.Controls.Add(this.getQty);
            this.guna2GroupBox3.Controls.Add(this.label16);
            this.guna2GroupBox3.Controls.Add(this.checkBox1);
            this.guna2GroupBox3.Controls.Add(this.label15);
            this.guna2GroupBox3.Controls.Add(this.guna2HtmlLabel8);
            this.guna2GroupBox3.Controls.Add(this.guna2HtmlLabel7);
            this.guna2GroupBox3.Controls.Add(this.label14);
            this.guna2GroupBox3.Controls.Add(this.label13);
            this.guna2GroupBox3.Controls.Add(this.label12);
            this.guna2GroupBox3.Controls.Add(this.label9);
            this.guna2GroupBox3.Controls.Add(this.btnItem_Sold);
            this.guna2GroupBox3.Controls.Add(this.dataGridView2);
            this.guna2GroupBox3.Controls.Add(this.tbTotal);
            this.guna2GroupBox3.Controls.Add(this.tbPrice);
            this.guna2GroupBox3.Controls.Add(this.tbQuantity);
            this.guna2GroupBox3.Controls.Add(this.tbPatName);
            this.guna2GroupBox3.Controls.Add(this.tbPatID);
            this.guna2GroupBox3.Controls.Add(this.cbLoadDrugsName);
            this.guna2GroupBox3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox3.Location = new System.Drawing.Point(17, 35);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.ShadowDecoration.Parent = this.guna2GroupBox3;
            this.guna2GroupBox3.Size = new System.Drawing.Size(702, 508);
            this.guna2GroupBox3.TabIndex = 0;
            this.guna2GroupBox3.Text = "                                                                       Sell Items" +
    "";
            // 
            // getQty
            // 
            this.getQty.AutoSize = true;
            this.getQty.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getQty.ForeColor = System.Drawing.Color.Black;
            this.getQty.Location = new System.Drawing.Point(190, 237);
            this.getQty.Name = "getQty";
            this.getQty.Size = new System.Drawing.Size(17, 19);
            this.getQty.TabIndex = 34;
            this.getQty.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(38, 237);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(119, 19);
            this.label16.TabIndex = 33;
            this.label16.Text = "Quantity In Stock:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(276, 56);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(56, 23);
            this.checkBox1.TabIndex = 32;
            this.checkBox1.Text = "view";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(646, 191);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 19);
            this.label15.TabIndex = 31;
            this.label15.Text = "Naira";
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(12, 177);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(69, 21);
            this.guna2HtmlLabel8.TabIndex = 30;
            this.guna2HtmlLabel8.Text = "Unit Price";
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(10, 107);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(85, 21);
            this.guna2HtmlLabel7.TabIndex = 29;
            this.guna2HtmlLabel7.Text = "Items Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(401, 191);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 19);
            this.label14.TabIndex = 27;
            this.label14.Text = "Total ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(384, 107);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 19);
            this.label13.TabIndex = 26;
            this.label13.Text = "Unit Qty";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(348, 55);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 19);
            this.label12.TabIndex = 25;
            this.label12.Text = "Patient Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 19);
            this.label9.TabIndex = 22;
            this.label9.Text = "PatientID";
            // 
            // btnItem_Sold
            // 
            this.btnItem_Sold.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnItem_Sold.BorderRadius = 12;
            this.btnItem_Sold.CheckedState.Parent = this.btnItem_Sold;
            this.btnItem_Sold.CustomImages.Parent = this.btnItem_Sold;
            this.btnItem_Sold.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnItem_Sold.ForeColor = System.Drawing.Color.White;
            this.btnItem_Sold.HoverState.Parent = this.btnItem_Sold;
            this.btnItem_Sold.Location = new System.Drawing.Point(538, 237);
            this.btnItem_Sold.Name = "btnItem_Sold";
            this.btnItem_Sold.ShadowDecoration.Parent = this.btnItem_Sold;
            this.btnItem_Sold.Size = new System.Drawing.Size(122, 21);
            this.btnItem_Sold.TabIndex = 21;
            this.btnItem_Sold.Text = "Sell Item";
            this.btnItem_Sold.Click += new System.EventHandler(this.btnItem_Sold_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(16, 260);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(667, 213);
            this.dataGridView2.TabIndex = 20;
            // 
            // tbTotal
            // 
            this.tbTotal.AutoRoundedCorners = true;
            this.tbTotal.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbTotal.BorderRadius = 14;
            this.tbTotal.BorderThickness = 2;
            this.tbTotal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbTotal.DefaultText = "";
            this.tbTotal.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbTotal.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbTotal.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbTotal.DisabledState.Parent = this.tbTotal;
            this.tbTotal.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbTotal.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbTotal.FocusedState.Parent = this.tbTotal;
            this.tbTotal.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbTotal.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbTotal.HoverState.Parent = this.tbTotal;
            this.tbTotal.Location = new System.Drawing.Point(450, 184);
            this.tbTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.PasswordChar = '\0';
            this.tbTotal.PlaceholderText = "N";
            this.tbTotal.SelectedText = "";
            this.tbTotal.ShadowDecoration.Parent = this.tbTotal;
            this.tbTotal.Size = new System.Drawing.Size(198, 31);
            this.tbTotal.TabIndex = 19;
            // 
            // tbPrice
            // 
            this.tbPrice.AutoRoundedCorners = true;
            this.tbPrice.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbPrice.BorderRadius = 14;
            this.tbPrice.BorderThickness = 2;
            this.tbPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbPrice.DefaultText = "";
            this.tbPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbPrice.DisabledState.Parent = this.tbPrice;
            this.tbPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbPrice.FocusedState.Parent = this.tbPrice;
            this.tbPrice.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbPrice.HoverState.Parent = this.tbPrice;
            this.tbPrice.Location = new System.Drawing.Point(96, 174);
            this.tbPrice.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbPrice.Name = "tbPrice";
            this.tbPrice.PasswordChar = '\0';
            this.tbPrice.PlaceholderText = "";
            this.tbPrice.SelectedText = "";
            this.tbPrice.ShadowDecoration.Parent = this.tbPrice;
            this.tbPrice.Size = new System.Drawing.Size(173, 31);
            this.tbPrice.TabIndex = 18;
            this.tbPrice.TextChanged += new System.EventHandler(this.tbPrice_TextChanged);
            // 
            // tbQuantity
            // 
            this.tbQuantity.AutoRoundedCorners = true;
            this.tbQuantity.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbQuantity.BorderRadius = 12;
            this.tbQuantity.BorderThickness = 2;
            this.tbQuantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbQuantity.DefaultText = "";
            this.tbQuantity.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbQuantity.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbQuantity.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbQuantity.DisabledState.Parent = this.tbQuantity;
            this.tbQuantity.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbQuantity.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbQuantity.FocusedState.Parent = this.tbQuantity;
            this.tbQuantity.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbQuantity.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbQuantity.HoverState.Parent = this.tbQuantity;
            this.tbQuantity.Location = new System.Drawing.Point(451, 107);
            this.tbQuantity.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbQuantity.Name = "tbQuantity";
            this.tbQuantity.PasswordChar = '\0';
            this.tbQuantity.PlaceholderText = "Enter quantity";
            this.tbQuantity.SelectedText = "";
            this.tbQuantity.ShadowDecoration.Parent = this.tbQuantity;
            this.tbQuantity.Size = new System.Drawing.Size(234, 27);
            this.tbQuantity.TabIndex = 17;
            this.tbQuantity.TextChanged += new System.EventHandler(this.tbQuantity_TextChanged);
            this.tbQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbQuantity_KeyPress);
            // 
            // tbPatName
            // 
            this.tbPatName.AutoRoundedCorners = true;
            this.tbPatName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbPatName.BorderRadius = 14;
            this.tbPatName.BorderThickness = 2;
            this.tbPatName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbPatName.DefaultText = "";
            this.tbPatName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbPatName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbPatName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbPatName.DisabledState.Parent = this.tbPatName;
            this.tbPatName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbPatName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbPatName.FocusedState.Parent = this.tbPatName;
            this.tbPatName.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbPatName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbPatName.HoverState.Parent = this.tbPatName;
            this.tbPatName.Location = new System.Drawing.Point(453, 48);
            this.tbPatName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPatName.Name = "tbPatName";
            this.tbPatName.PasswordChar = '\0';
            this.tbPatName.PlaceholderText = "";
            this.tbPatName.SelectedText = "";
            this.tbPatName.ShadowDecoration.Parent = this.tbPatName;
            this.tbPatName.Size = new System.Drawing.Size(233, 31);
            this.tbPatName.TabIndex = 16;
            // 
            // tbPatID
            // 
            this.tbPatID.AutoRoundedCorners = true;
            this.tbPatID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tbPatID.BorderRadius = 15;
            this.tbPatID.BorderThickness = 2;
            this.tbPatID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbPatID.DefaultText = "";
            this.tbPatID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbPatID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbPatID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbPatID.DisabledState.Parent = this.tbPatID;
            this.tbPatID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbPatID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbPatID.FocusedState.Parent = this.tbPatID;
            this.tbPatID.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tbPatID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbPatID.HoverState.Parent = this.tbPatID;
            this.tbPatID.Location = new System.Drawing.Point(96, 56);
            this.tbPatID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbPatID.Name = "tbPatID";
            this.tbPatID.PasswordChar = '\0';
            this.tbPatID.PlaceholderText = "";
            this.tbPatID.SelectedText = "";
            this.tbPatID.ShadowDecoration.Parent = this.tbPatID;
            this.tbPatID.Size = new System.Drawing.Size(173, 32);
            this.tbPatID.TabIndex = 15;
            this.tbPatID.TextChanged += new System.EventHandler(this.tbPatID_TextChanged);
            // 
            // cbLoadDrugsName
            // 
            this.cbLoadDrugsName.AutoRoundedCorners = true;
            this.cbLoadDrugsName.BackColor = System.Drawing.Color.Transparent;
            this.cbLoadDrugsName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbLoadDrugsName.BorderRadius = 17;
            this.cbLoadDrugsName.BorderThickness = 2;
            this.cbLoadDrugsName.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbLoadDrugsName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLoadDrugsName.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbLoadDrugsName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbLoadDrugsName.FocusedState.Parent = this.cbLoadDrugsName;
            this.cbLoadDrugsName.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbLoadDrugsName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbLoadDrugsName.HoverState.Parent = this.cbLoadDrugsName;
            this.cbLoadDrugsName.ItemHeight = 30;
            this.cbLoadDrugsName.ItemsAppearance.Parent = this.cbLoadDrugsName;
            this.cbLoadDrugsName.Location = new System.Drawing.Point(98, 107);
            this.cbLoadDrugsName.Name = "cbLoadDrugsName";
            this.cbLoadDrugsName.ShadowDecoration.Parent = this.cbLoadDrugsName;
            this.cbLoadDrugsName.Size = new System.Drawing.Size(173, 36);
            this.cbLoadDrugsName.TabIndex = 14;
            this.cbLoadDrugsName.SelectedIndexChanged += new System.EventHandler(this.cbLoadDrugsName_SelectedIndexChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.guna2GroupBox4);
            this.tabPage5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage5.Location = new System.Drawing.Point(4, 24);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(731, 587);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Sells checkout";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // guna2GroupBox4
            // 
            this.guna2GroupBox4.AutoRoundedCorners = true;
            this.guna2GroupBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2GroupBox4.BorderRadius = 246;
            this.guna2GroupBox4.Controls.Add(this.guna2HtmlLabel6);
            this.guna2GroupBox4.Controls.Add(this.tb_PatID);
            this.guna2GroupBox4.Controls.Add(this.guna2HtmlLabel9);
            this.guna2GroupBox4.Controls.Add(this.lblTotal);
            this.guna2GroupBox4.Controls.Add(this.btnCheckout);
            this.guna2GroupBox4.Controls.Add(this.dataGridView3);
            this.guna2GroupBox4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GroupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox4.Location = new System.Drawing.Point(41, 63);
            this.guna2GroupBox4.Name = "guna2GroupBox4";
            this.guna2GroupBox4.ShadowDecoration.Parent = this.guna2GroupBox4;
            this.guna2GroupBox4.Size = new System.Drawing.Size(649, 495);
            this.guna2GroupBox4.TabIndex = 0;
            this.guna2GroupBox4.Text = "                                                                     Checkout";
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(86, 105);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(64, 21);
            this.guna2HtmlLabel6.TabIndex = 11;
            this.guna2HtmlLabel6.Text = "Patient Id:";
            // 
            // tb_PatID
            // 
            this.tb_PatID.AutoRoundedCorners = true;
            this.tb_PatID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tb_PatID.BorderRadius = 17;
            this.tb_PatID.BorderThickness = 2;
            this.tb_PatID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_PatID.DefaultText = "";
            this.tb_PatID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_PatID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_PatID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_PatID.DisabledState.Parent = this.tb_PatID;
            this.tb_PatID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_PatID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_PatID.FocusedState.Parent = this.tb_PatID;
            this.tb_PatID.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.tb_PatID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_PatID.HoverState.Parent = this.tb_PatID;
            this.tb_PatID.Location = new System.Drawing.Point(162, 99);
            this.tb_PatID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_PatID.Name = "tb_PatID";
            this.tb_PatID.PasswordChar = '\0';
            this.tb_PatID.PlaceholderText = "Patient ID";
            this.tb_PatID.SelectedText = "";
            this.tb_PatID.ShadowDecoration.Parent = this.tb_PatID;
            this.tb_PatID.Size = new System.Drawing.Size(123, 36);
            this.tb_PatID.TabIndex = 10;
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(86, 387);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(37, 21);
            this.guna2HtmlLabel9.TabIndex = 9;
            this.guna2HtmlLabel9.Text = "Total: ";
            // 
            // lblTotal
            // 
            this.lblTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblTotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(432, 390);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(75, 21);
            this.lblTotal.TabIndex = 8;
            this.lblTotal.Text = "========";
            // 
            // btnCheckout
            // 
            this.btnCheckout.AutoRoundedCorners = true;
            this.btnCheckout.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCheckout.BorderRadius = 13;
            this.btnCheckout.CheckedState.Parent = this.btnCheckout;
            this.btnCheckout.CustomImages.Parent = this.btnCheckout;
            this.btnCheckout.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnCheckout.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnCheckout.ForeColor = System.Drawing.Color.White;
            this.btnCheckout.HoverState.Parent = this.btnCheckout;
            this.btnCheckout.Location = new System.Drawing.Point(417, 435);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.ShadowDecoration.Parent = this.btnCheckout;
            this.btnCheckout.Size = new System.Drawing.Size(100, 28);
            this.btnCheckout.TabIndex = 7;
            this.btnCheckout.Text = "CheckOut";
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click_1);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(87, 140);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(476, 223);
            this.dataGridView3.TabIndex = 6;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnClose.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnClose.BorderRadius = 12;
            this.btnClose.BorderThickness = 1;
            this.btnClose.CheckedState.Parent = this.btnClose;
            this.btnClose.CustomImages.Parent = this.btnClose;
            this.btnClose.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnClose.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.HoverState.Parent = this.btnClose;
            this.btnClose.Location = new System.Drawing.Point(554, 673);
            this.btnClose.Name = "btnClose";
            this.btnClose.ShadowDecoration.Parent = this.btnClose;
            this.btnClose.Size = new System.Drawing.Size(180, 45);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Close";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(794, 730);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Products   General Hospital Management Solution";
            this.Load += new System.EventHandler(this.frmProduct_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.guna2GroupBox2.ResumeLayout(false);
            this.guna2GroupBox2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.guna2GroupBox3.ResumeLayout(false);
            this.guna2GroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.guna2GroupBox4.ResumeLayout(false);
            this.guna2GroupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private Guna.UI2.WinForms.Guna2Button btnAddStock;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox tbItemLocation;
        private Guna.UI2.WinForms.Guna2TextBox tbItemDetails;
        private Guna.UI2.WinForms.Guna2TextBox tbItemQuantity;
        private Guna.UI2.WinForms.Guna2TextBox tbItemPrice;
        private Guna.UI2.WinForms.Guna2TextBox tbItemName;
        private Guna.UI2.WinForms.Guna2ComboBox cbSuppliedBy;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2Button btnRemoveItem;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2Button btnUpdateItem;
        private Guna.UI2.WinForms.Guna2HtmlLabel lebel;
        private Guna.UI2.WinForms.Guna2HtmlLabel Label;
        private Guna.UI2.WinForms.Guna2HtmlLabel gunaLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel ItemLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2TextBox tbUpdateProLocation;
        private Guna.UI2.WinForms.Guna2ComboBox cbUpdateSuppliedBy;
        private Guna.UI2.WinForms.Guna2TextBox tbUpdateProDetails;
        private Guna.UI2.WinForms.Guna2TextBox tbUpdateProQ;
        private Guna.UI2.WinForms.Guna2TextBox tbUpdateProPrice;
        private Guna.UI2.WinForms.Guna2TextBox tbUpdateProName;
        private Guna.UI2.WinForms.Guna2TextBox tbUpdateProID;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2Button btnClose;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private System.Windows.Forms.Label getQty;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label15;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2Button btnItem_Sold;
        private System.Windows.Forms.DataGridView dataGridView2;
        private Guna.UI2.WinForms.Guna2TextBox tbTotal;
        private Guna.UI2.WinForms.Guna2TextBox tbPrice;
        private Guna.UI2.WinForms.Guna2TextBox tbQuantity;
        private Guna.UI2.WinForms.Guna2TextBox tbPatName;
        private Guna.UI2.WinForms.Guna2TextBox tbPatID;
        private Guna.UI2.WinForms.Guna2ComboBox cbLoadDrugsName;
        private System.Windows.Forms.DateTimePicker dtpExpiryDate;
        private System.Windows.Forms.DateTimePicker dtpManufactureDate;
        private System.Windows.Forms.DateTimePicker dtpUpExpiryDate;
        private System.Windows.Forms.DateTimePicker dtpUpManDate;
        private System.Windows.Forms.TabPage tabPage5;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        public Guna.UI2.WinForms.Guna2TextBox tb_PatID;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblTotal;
        private Guna.UI2.WinForms.Guna2Button btnCheckout;
        private System.Windows.Forms.DataGridView dataGridView3;
    }
}